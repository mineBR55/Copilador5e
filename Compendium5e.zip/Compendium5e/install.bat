@echo off
rdk i
pause
