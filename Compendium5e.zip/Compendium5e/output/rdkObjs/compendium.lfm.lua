require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_frmCompendium5e()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", obj.setNodeObject);

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setName("frmCompendium5e");
    obj:setFormType("tablesDock");
    obj:setDataType("br.com.minebr55.compendium5e");
    obj:setTitle("Compendio 5e");


local common=require("common.lua")
local index=require("data/index.lua")
local entries=nil
local activeCategory="none"
local PAGE_SIZE=15
local currentPage=1
local totalPages=1
local slotIds={}
local favorites={}
local currentEntryId=nil
local currentEntryMeta=nil
local lootTables=nil
local lootEngine=nil
local genericTables=nil
local tableEngine=nil

local function setRowsEmpty()
 for i=1,PAGE_SIZE do self["row"..tostring(i)].text=""; self["row"..tostring(i)].visible=false; slotIds[i]=nil end
end
local function hideAllPanels()
 self.pnlReferenceNav.visible=false; self.pnlBrowser.visible=false; self.pnlArea.visible=false; self.pnlLoot.visible=false; self.pnlCraft.visible=false; self.pnlTables.visible=false; self.pnlStats.visible=false; self.pnlCR.visible=false; self.pnlEncounters.visible=false
 self.pnlSpellFilters.visible=false; self.pnlCreatureFilters.visible=false; self.pnlItemFilters.visible=false; self.pnlRarityChecks.visible=false; self.pnlCreatureTabs.visible=false
 self.lblRarity.visible=false; self.cmbRarity.visible=false; self.lblAttune.visible=false; self.cmbAttune.visible=false; self.btnCraft.visible=false
end
local function resetView()
 hideAllPanels(); self.edtSearch.text=""; self.chkRitual.checked=false; self.chkConc.checked=false; currentPage=1; setRowsEmpty(); self.lblTitle.text="Compendio"; self.lblSub.text="Selecione um resultado."; self.txtDetails.text=""; self.lblPage.text="Pagina 1 / 1"
end
local function categoryOK(e) if activeCategory=="favorites" then return favorites[e.id]==true end; return activeCategory=="all" or e.category==activeCategory end
local function uniqueValues(field, predicate, allText)
 local seen={}; local vals={}
 for _,e in ipairs(index) do if predicate(e) then local v=e[field]; if v~=nil and v~="" and not seen[v] then seen[v]=true; table.insert(vals,v) end end end
 table.sort(vals,function(a,b) return common.normalize(a)<common.normalize(b) end)
 local items={allText}; local values={"all"}; for _,v in ipairs(vals) do table.insert(items,v); table.insert(values,v) end
 return items,values
end
local function rebuildFilters()
 local items,values=uniqueValues("source",categoryOK,"Todos os livros"); self.cmbSource.items=items; self.cmbSource.values=values; self.cmbSource.value="all"
 local iti,itv=uniqueValues("itemType",function(e) return (activeCategory=="item" or activeCategory=="magicitem") and e.category==activeCategory end,"Todos tipos"); self.cmbItemType.items=iti; self.cmbItemType.values=itv; self.cmbItemType.value="all"
 local ri,rv=uniqueValues("rarity",function(e) return activeCategory=="magicitem" and e.category=="magicitem" end,"Todas raridades"); self.cmbRarity.items=ri; self.cmbRarity.values=rv; self.cmbRarity.value="all"
 local ci,cv=uniqueValues("cr",function(e) return activeCategory=="creature" and e.category=="creature" end,"Todos CR"); self.cmbCR.items=ci; self.cmbCR.values=cv; self.cmbCR.value="all"
 self.pnlItemFilters.visible=(activeCategory=="item" or activeCategory=="magicitem"); self.lblRarity.visible=false; self.cmbRarity.visible=false; self.pnlRarityChecks.visible=(activeCategory=="magicitem"); self.lblAttune.visible=self.lblRarity.visible; self.cmbAttune.visible=self.lblRarity.visible; self.pnlCreatureFilters.visible=(activeCategory=="creature")
 local li,lv=uniqueValues("level",function(e) return activeCategory=="spell" and e.category=="spell" end,"Todos niveis"); self.cmbLevel.items=li; self.cmbLevel.values=lv; self.cmbLevel.value="all"
 local si,sv=uniqueValues("school",function(e) return activeCategory=="spell" and e.category=="spell" end,"Todas escolas"); self.cmbSchool.items=si; self.cmbSchool.values=sv; self.cmbSchool.value="all"
 self.pnlSpellFilters.visible=(activeCategory=="spell")
 local classSeen={}; local classItems={"Todas classes"}; local classValues={"all"}; if activeCategory=="spell" then for _,e in ipairs(index) do if e.category=="spell" then for c in string.gmatch(e.spellClasses or "","[^,]+") do if not classSeen[c] then classSeen[c]=true; table.insert(classItems,c); table.insert(classValues,c) end end end end end; self.cmbSpellClass.items=classItems; self.cmbSpellClass.values=classValues; self.cmbSpellClass.value="all"
 local ti,tv=uniqueValues("creatureType",function(e) return activeCategory=="creature" and e.category=="creature" end,"Todos tipos"); self.cmbCreatureType.items=ti; self.cmbCreatureType.values=tv; self.cmbCreatureType.value="all"
 local zi,zv=uniqueValues("size",function(e) return activeCategory=="creature" and e.category=="creature" end,"Todos tamanhos"); self.cmbSize.items=zi; self.cmbSize.values=zv; self.cmbSize.value="all"
end
local function matches(e)
 local origin=self.cmbOrigin.value or "all"; local originOK=(origin=="all" or e.origin==origin)
 local ok=categoryOK(e) and originOK and common.contains(e.name,self.edtSearch.text) and ((self.cmbSource.value or "all")=="all" or e.source==self.cmbSource.value) and ((self.cmbEdition.value or "all")=="all" or e.edition==self.cmbEdition.value)
 if activeCategory=="spell" then
  ok=ok and ((self.cmbLevel.value or "all")=="all" or e.level==self.cmbLevel.value) and ((self.cmbSchool.value or "all")=="all" or e.school==self.cmbSchool.value)
  if self.chkRitual.checked then ok=ok and e.ritual=="yes" end
  if self.chkConc.checked then ok=ok and e.concentration=="yes" end
  local sc=self.cmbSpellClass.value or "all"; if sc~="all" then ok=ok and string.find(","..(e.spellClasses or "")..",",","..sc..",",1,true)~=nil end
 end
 if activeCategory=="item" or activeCategory=="magicitem" then
  local anyType=self.chkWeapon.checked or self.chkArmor.checked or self.chkGear.checked or self.chkOtherType.checked
  if anyType then local t=string.lower(e.itemType or ""); local isWeapon=string.find(t,"weapon",1,true)~=nil or string.find(t,"arma",1,true)~=nil; local isArmor=string.find(t,"armor",1,true)~=nil or string.find(t,"armadura",1,true)~=nil; local isGear=string.find(t,"gear",1,true)~=nil or string.find(t,"tool",1,true)~=nil or string.find(t,"equip",1,true)~=nil; local pass=(self.chkWeapon.checked and isWeapon) or (self.chkArmor.checked and isArmor) or (self.chkGear.checked and isGear) or (self.chkOtherType.checked and not isWeapon and not isArmor and not isGear); ok=ok and pass end
 end
 if activeCategory=="magicitem" then
  local anyR=self.chkCommon.checked or self.chkUncommon.checked or self.chkRare.checked or self.chkVeryRare.checked or self.chkLegendary.checked or self.chkArtifact.checked
  if anyR then local r=string.lower(e.rarity or ""); ok=ok and ((self.chkCommon.checked and r=="common") or (self.chkUncommon.checked and r=="uncommon") or (self.chkRare.checked and r=="rare") or (self.chkVeryRare.checked and r=="very rare") or (self.chkLegendary.checked and r=="legendary") or (self.chkArtifact.checked and r=="artifact")) end
  ok=ok and ((self.cmbAttune.value or "all")=="all" or e.attunement==self.cmbAttune.value)
 end
 if activeCategory=="creature" then ok=ok and ((self.cmbCR.value or "all")=="all" or e.cr==self.cmbCR.value) and ((self.cmbCreatureType.value or "all")=="all" or e.creatureType==self.cmbCreatureType.value) and ((self.cmbSize.value or "all")=="all" or e.size==self.cmbSize.value) end
 return ok
end
local function renderPage()
 setRowsEmpty(); if activeCategory=="none" then self.lblCount.text="Escolha uma secao"; return end
 local total=0; for _,e in ipairs(index) do if matches(e) then total=total+1 end end
 totalPages=math.max(1,math.ceil(total/PAGE_SIZE)); if currentPage>totalPages then currentPage=totalPages end
 local first=(currentPage-1)*PAGE_SIZE+1; local last=currentPage*PAGE_SIZE; local hit=0; local slot=0
 for _,e in ipairs(index) do if matches(e) then hit=hit+1; if hit>=first and hit<=last then slot=slot+1; slotIds[slot]=e.id; self["row"..tostring(slot)].text=(favorites[e.id] and "★ " or "")..e.name.."  |  "..(e.source or "").."  |  "..(e.edition or ""); self["row"..tostring(slot)].visible=true end; if hit>last then break end end end
 self.lblCount.text=tostring(total).." resultado(s)"; self.lblPage.text="Pagina "..tostring(currentPage).." / "..tostring(totalPages)
end
local function isExtraCategory(category)
 local extras={optionalfeature=true,background=true,charoption=true,actionref=true,reward=true,object=true,traphazard=true,psionic=true,vehicle=true,deity=true,language=true,bastion=true}
 return extras[category]==true
end
local function toggleReferenceNav()
 resetView(); activeCategory="none"; self.pnlReferenceNav.visible=true; self.lblSection.text="Referencias do Compendio"; self.lblCount.text="Escolha uma categoria acima"
end
local function isReferenceCategory(category)
 return category=="optionalfeature" or category=="background" or category=="charoption" or category=="actionref" or category=="reward" or category=="object" or category=="traphazard" or category=="psionic" or category=="vehicle"
end
local function chooseSection(category,title)
 activeCategory=category; resetView(); self.pnlReferenceNav.visible=isReferenceCategory(category); self.pnlBrowser.visible=true; self.lblSection.text=title; rebuildFilters(); renderPage()
end
local function clearSearch() self.edtSearch.text=""; currentPage=1; self.lblTitle.text="Compendio"; self.lblSub.text="Selecione um resultado."; self.txtDetails.text=""; renderPage() end
local function searchNow() currentPage=1; renderPage() end
local function prevPage() if currentPage>1 then currentPage=currentPage-1; renderPage() end end
local function nextPage() if currentPage<totalPages then currentPage=currentPage+1; renderPage() end end
local function areaCalculate()
 local raw=string.gsub(self.edtAreaRadius.text or "",",","."); local meters=tonumber(raw)
 if meters==nil or meters<=0 then self.lblAreaResult.text="Informe um raio maior que zero."; return end
 local r=meters/1.5; local limit=math.ceil(r+0.5); local count=0
 for x=-limit,limit-1 do for y=-limit,limit-1 do local cx=x+0.5; local cy=y+0.5; if (cx*cx+cy*cy)<=(r*r+0.000001) then count=count+1 end end end
 self.lblAreaResult.text=string.format("Raio: %.2f quadrados | Diametro: %.2f | Aproximadamente %d quadrados afetados",r,r*2,count)
end
local function showAreaTool()
 activeCategory="none"; resetView();  self.pnlBrowser.visible=false; self.pnlArea.visible=true; self.lblSection.text="Areas no grid"
end
local detailBody=""
local function creatureSection(mode)
 if detailBody=="" then return end
 if mode=="all" then self.txtDetails.text=detailBody; return end
 local markers={stats="=== ESTATISTICAS ===",traits="=== TRACOS ===",actions="=== ACOES ===",bonus="=== ACOES BONUS ===",reactions="=== REACOES ===",legendary="=== ACOES LENDARIAS ==="}
 local target=markers[mode]; if target==nil then return end
 local p=string.find(detailBody,target,1,true); if p==nil then self.txtDetails.text="Esta criatura nao possui esta secao."; return end
 local tail=string.sub(detailBody,p); local nextPos=nil
 for _,m in pairs(markers) do if m~=target then local q=string.find(tail,m,2,true); if q~=nil and (nextPos==nil or q<nextPos) then nextPos=q end end end
 if nextPos~=nil then tail=string.sub(tail,1,nextPos-1) end; self.txtDetails.text=tail
end
local function openSlot(i)
 local id=slotIds[i]; if id==nil then return end; currentEntryId=id; currentEntryMeta=nil; for _,e in ipairs(index) do if e.id==id then currentEntryMeta=e; break end end; self.btnCraft.visible=(currentEntryMeta~=nil and ((currentEntryMeta.category=="magicitem" and currentEntryMeta.craftDays2024~="") or (currentEntryMeta.category=="item" and currentEntryMeta.nonmagicCraftDays~="")))
 if entries==nil then entries=require("data/entries.lua") end
 local d=entries[id]; if d~=nil then self.lblTitle.text=d.title or ""; self.lblSub.text=d.subtitle or ""; detailBody=d.body or ""; self.txtDetails.text=detailBody; self.pnlCreatureTabs.visible=(activeCategory=="creature") end
end
local function toggleFavorite()
 if currentEntryId==nil then return end; favorites[currentEntryId]=not favorites[currentEntryId]; self.btnFavorite.text=favorites[currentEntryId] and "★ Favorito" or "☆ Favoritar"; renderPage()
end
local function showQuickReference()
 chooseSection("condition","Referencia Rapida 2024"); self.cmbEdition.value="2024"; searchNow()
end
local function showFavorites() chooseSection("favorites","Favoritos da sessao") end
local calculateCrafting
local function showCraftingTab()
 resetView(); self.pnlBrowser.visible=false; self.pnlArea.visible=false; self.pnlLoot.visible=false; self.pnlTables.visible=false; self.pnlStats.visible=false; self.pnlCR.visible=false; self.pnlEncounters.visible=false; self.pnlCraft.visible=true; self.lblSection.text="Crafting 2024"
 if currentEntryMeta~=nil and currentEntryMeta.category=="magicitem" then self.lblCraftItem.text=currentEntryMeta.name or "Item magico"; self.lblCraftRarity.text=(currentEntryMeta.category=="magicitem" and ("Raridade: "..(currentEntryMeta.rarity or "")) or "Item comum - regras PHB 2024"); self.edtCraftWorkers.text="1"; calculateCrafting() else self.lblCraftItem.text="Selecione um item magico no compendio"; self.lblCraftRarity.text=""; self.txtCraft.text="Abra um item magico e use Calcular crafting para preencher a calculadora." end
end
local crEngine=nil
local function calculateCR()
 if crEngine==nil then crEngine=require("cr_engine.lua") end
 local hp=tonumber(self.edtCRHP.text or "") or 1; local ac=tonumber(self.edtCRAC.text or "") or 13; local dpr=tonumber(self.edtCRDPR.text or "") or 1; local atk=tonumber(self.edtCRAttack.text or "") or 3; local dc=tonumber(self.edtCRDC.text or "") or 13
 if hp<1 then hp=1 end; if dpr<0 then dpr=0 end
 local final,def,off,dr,orr=crEngine.calculate(hp,ac,dpr,atk,dc,self.chkCRSave.checked)
 local attackText="ataque +"..atk.." (referencia +"..orr.atk..")"
 if self.chkCRSave.checked then attackText="CD "..dc.." (referencia "..orr.dc..")" end
 local output={"CR final estimado: "..final,"CR defensivo: "..def,"CR ofensivo: "..off,"","Defesa: "..hp.." PV, CA "..ac.." (referencia CA "..dr.ac..")","Ofensa: "..dpr.." dano/rodada, "..attackText,"","Metodo 2014: PV define CR defensivo e CA ajusta; dano/rodada define CR ofensivo e ataque/CD ajusta."}
 self.txtCR.text=table.concat(output,string.char(10))
end
local function showCR()
 resetView(); self.pnlBrowser.visible=false; self.pnlArea.visible=false; self.pnlLoot.visible=false; self.pnlCraft.visible=false; self.pnlTables.visible=false; self.pnlStats.visible=false; self.pnlCR.visible=true; self.lblSection.text="Calculadora de CR"; calculateCR()
end
local function showStats()
 resetView(); self.pnlBrowser.visible=false; self.pnlArea.visible=false; self.pnlLoot.visible=false; self.pnlCraft.visible=false; self.pnlTables.visible=false; self.pnlCR.visible=false; self.pnlStats.visible=true; self.lblSection.text="Gerador de Atributos"; self.txtStats.text="Standard Array: 15, 14, 13, 12, 10, 8"
end
local function rollStats()
 local dice=tonumber(self.edtStatDice.text or "4") or 4; local drop=tonumber(self.edtStatDrop.text or "1") or 1; if dice<1 then dice=1 end; if drop<0 then drop=0 end; if drop>=dice then drop=dice-1 end
 local lines={}; local totals={}; for a=1,6 do local rolls={}; for i=1,dice do table.insert(rolls,math.random(1,6)) end; table.sort(rolls); local total=0; for i=drop+1,#rolls do total=total+rolls[i] end; table.insert(totals,total); table.insert(lines,table.concat(rolls,", ").." -> "..total) end; table.sort(totals,function(a,b) return a>b end); self.txtStats.text="Resultados: "..table.concat(totals,", ").."\n\n"..table.concat(lines,"\n")
end
local function pointBuy()
 self.txtStats.text="Point Buy (27 pontos)\nCustos: 8=0, 9=1, 10=2, 11=3, 12=4, 13=5, 14=7, 15=9\nUse como referencia para distribuir FOR, DES, CON, INT, SAB e CAR."
end
local function filterGenericTables()
 if genericTables==nil then return end; local q=string.lower(self.edtTableSearch.text or ""); local book=self.cmbTableBook.value or "all"; local items={}; local values={}
 for i,t in ipairs(genericTables) do local ok=(q=="" or string.find(string.lower(t.name or ""),q,1,true)~=nil); if book~="all" then ok=ok and t.source==book end; if ok then table.insert(items,t.name.." | "..t.source); table.insert(values,tostring(i)) end end
 self.cmbGenericTable.items=items; self.cmbGenericTable.values=values; if #values>0 then self.cmbGenericTable.value=values[1] else self.cmbGenericTable.value=nil end
end
local function populateTableBooks()
 local seen={}; local items={"Todos os livros"}; local vals={"all"}; for _,t in ipairs(genericTables or {}) do if not seen[t.source] then seen[t.source]=true; table.insert(items,t.source); table.insert(vals,t.source) end end; self.cmbTableBook.items=items; self.cmbTableBook.values=vals; self.cmbTableBook.value="all"
end
local function showEncounters()
 resetView(); self.pnlBrowser.visible=false; self.pnlArea.visible=false; self.pnlLoot.visible=false; self.pnlCraft.visible=false; self.pnlTables.visible=false; self.pnlStats.visible=false; self.pnlCR.visible=false; self.pnlEncounters.visible=false; self.pnlEncounters.visible=true; self.lblSection.text="Encontros 2024"; if tableEngine==nil then tableEngine=require("table_engine.lua") end; if genericTables==nil then local ok,v=pcall(require,"data/tables.lua"); genericTables=ok and v or {} end
 local items={}; local vals={}; for i,t in ipairs(genericTables) do local n=string.lower(t.name or ""); if t.source=="XDMG" and string.find(n,"encounter",1,true) then table.insert(items,t.name); table.insert(vals,tostring(i)) end end; self.cmbEncounterTable.items=items; self.cmbEncounterTable.values=vals; if #vals>0 then self.cmbEncounterTable.value=vals[1] end
end
local function rollEncounter()
 local i=tonumber(self.cmbEncounterTable.value or ""); local t=i and genericTables[i] or nil; if not t then self.txtEncounter.text="Nenhuma tabela de encontro DMG 2024 encontrada nos dados importados."; return end; local r=tableEngine.roll(t.dice or "1d100"); local row=tableEngine.select(t.rows,r); self.txtEncounter.text=t.name.."\nRolagem: "..r.."\n\n"..(row and tableEngine.format(row.result) or "Sem resultado.")
end
local function showTables()
 resetView(); self.pnlBrowser.visible=false; self.pnlArea.visible=false; self.pnlLoot.visible=false; self.pnlCraft.visible=false; self.pnlTables.visible=true; self.lblSection.text="Tabelas"
 if tableEngine==nil then tableEngine=require("table_engine.lua") end
 if genericTables==nil then local ok,v=pcall(require,"data/tables.lua"); genericTables=ok and v or {} end
 populateTableBooks(); filterGenericTables()
end
local function rollGenericTable()
 local i=tonumber(self.cmbGenericTable.value or ""); local t=i and genericTables[i] or nil; if t==nil then self.txtTableResult.text="Nenhuma tabela importada."; return end
 local roll=tableEngine.roll(t.dice or "1d100"); local row=tableEngine.select(t.rows,roll); self.txtTableResult.text=t.name.."\nRolagem: "..roll.." ("..(t.dice or "1d100")..")\n\n"..(row and tableEngine.format(row.result) or "Sem resultado para esta rolagem.")
end
local function showLoot()
 resetView(); self.pnlBrowser.visible=false; self.pnlArea.visible=false; self.pnlTables.visible=false; self.pnlStats.visible=false; self.pnlCR.visible=false; self.pnlEncounters.visible=false; self.pnlLoot.visible=true; self.lblSection.text="Loot por CR"
 if lootEngine==nil then lootEngine=require("loot_engine.lua") end
 if lootTables==nil then local ok,v=pcall(require,"data/loot_tables.lua"); lootTables=ok and v or {} end
end
local function openCrafting()
 if currentEntryMeta==nil or (currentEntryMeta.category~="magicitem" and currentEntryMeta.category~="item") then return end
 self.pnlBrowser.visible=false; self.pnlLoot.visible=false; self.pnlArea.visible=false; self.pnlTables.visible=false; self.pnlStats.visible=false; self.pnlCR.visible=false; self.pnlEncounters.visible=false; self.pnlCraft.visible=true; self.lblSection.text="Crafting 2024"
 self.lblCraftItem.text=currentEntryMeta.name or "Item magico"; self.lblCraftRarity.text="Raridade: "..(currentEntryMeta.rarity or "")
 self.edtCraftWorkers.text="1"; calculateCrafting()
end
calculateCrafting=function()
 if currentEntryMeta==nil then return end; local workers=tonumber(self.edtCraftWorkers.text or "1") or 1; if workers<1 then workers=1 end
 local value=currentEntryMeta.market2024 or ""; local cost=tonumber(currentEntryMeta.craftCost2024 or ""); local days=tonumber(currentEntryMeta.craftDays2024 or "")
 if currentEntryMeta.category=="item" then cost=tonumber(currentEntryMeta.nonmagicCraftCost or ""); days=tonumber(currentEntryMeta.nonmagicCraftDays or ""); local price=tonumber(currentEntryMeta.purchaseGp or ""); if cost==nil or days==nil then self.txtCraft.text="Este item nao possui preco numerico importado para calcular crafting."; return end; self.txtCraft.text="Preco de compra: "..price.." PO\nMateriais: "..cost.." PO\nTempo base: "..days.." dia(s) de 8 horas\nTrabalhadores: "..workers.."\nTempo efetivo: "..(days/workers).." dia(s)\n\nRequer ferramenta apropriada e proficiencia."; return end
 if value=="priceless" then self.txtCraft.text="Valor padrao 2024: Inestimavel\nCrafting por raridade: nao aplicavel."; return end
 if cost==nil or days==nil then self.txtCraft.text="Sem valor de crafting 2024 para esta raridade."; return end
 self.txtCraft.text="Valor padrao 2024: "..value.." PO\nCusto de materiais: "..cost.." PO\nTempo base: "..days.." dias\nTrabalhadores: "..workers.."\nTempo efetivo: "..(days/workers).." dias\nJornada: 8 horas por dia."
end
local function generateLoot()
 local cr=tonumber(self.edtLootCR.text or ""); if cr==nil or cr<0 or cr>30 then self.txtLoot.text="Informe um CR entre 0 e 30."; return end
 self.txtLoot.text=lootEngine.generate(lootTables,index,cr,self.cmbLootEdition.value or "2014",self.cmbLootMode.value or "individual")
end



    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj);
    obj.rectangle1:setAlign("client");
    obj.rectangle1:setColor("#17191C");
    obj.rectangle1:setName("rectangle1");

    obj.layout1 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout1:setParent(obj);
    obj.layout1:setAlign("top");
    obj.layout1:setHeight(38);
    obj.layout1:setMargins({left=6, top=6, right=6, bottom=0});
    obj.layout1:setName("layout1");

    obj.button1 = GUI.fromHandle(_obj_newObject("button"));
    obj.button1:setParent(obj.layout1);
    obj.button1:setAlign("left");
    obj.button1:setWidth(70);
    obj.button1:setText("Busca");
    obj.button1:setName("button1");

    obj.button2 = GUI.fromHandle(_obj_newObject("button"));
    obj.button2:setParent(obj.layout1);
    obj.button2:setAlign("left");
    obj.button2:setWidth(70);
    obj.button2:setText("Magias");
    obj.button2:setName("button2");

    obj.button3 = GUI.fromHandle(_obj_newObject("button"));
    obj.button3:setParent(obj.layout1);
    obj.button3:setAlign("left");
    obj.button3:setWidth(78);
    obj.button3:setText("Especies");
    obj.button3:setName("button3");

    obj.button4 = GUI.fromHandle(_obj_newObject("button"));
    obj.button4:setParent(obj.layout1);
    obj.button4:setAlign("left");
    obj.button4:setWidth(70);
    obj.button4:setText("Classes");
    obj.button4:setName("button4");

    obj.button5 = GUI.fromHandle(_obj_newObject("button"));
    obj.button5:setParent(obj.layout1);
    obj.button5:setAlign("left");
    obj.button5:setWidth(60);
    obj.button5:setText("Feats");
    obj.button5:setName("button5");

    obj.button6 = GUI.fromHandle(_obj_newObject("button"));
    obj.button6:setParent(obj.layout1);
    obj.button6:setAlign("left");
    obj.button6:setWidth(60);
    obj.button6:setText("Itens");
    obj.button6:setName("button6");

    obj.button7 = GUI.fromHandle(_obj_newObject("button"));
    obj.button7:setParent(obj.layout1);
    obj.button7:setAlign("left");
    obj.button7:setWidth(75);
    obj.button7:setText("Magicos");
    obj.button7:setName("button7");

    obj.button8 = GUI.fromHandle(_obj_newObject("button"));
    obj.button8:setParent(obj.layout1);
    obj.button8:setAlign("left");
    obj.button8:setWidth(82);
    obj.button8:setText("Criaturas");
    obj.button8:setName("button8");

    obj.button9 = GUI.fromHandle(_obj_newObject("button"));
    obj.button9:setParent(obj.layout1);
    obj.button9:setAlign("left");
    obj.button9:setWidth(65);
    obj.button9:setText("Regras");
    obj.button9:setName("button9");

    obj.button10 = GUI.fromHandle(_obj_newObject("button"));
    obj.button10:setParent(obj.layout1);
    obj.button10:setAlign("left");
    obj.button10:setWidth(92);
    obj.button10:setText("Referencias");
    obj.button10:setName("button10");

    obj.layout2 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout2:setParent(obj);
    obj.layout2:setAlign("top");
    obj.layout2:setHeight(34);
    obj.layout2:setMargins({left=6, top=2, right=6, bottom=0});
    obj.layout2:setName("layout2");

    obj.label1 = GUI.fromHandle(_obj_newObject("label"));
    obj.label1:setParent(obj.layout2);
    obj.label1:setAlign("left");
    obj.label1:setWidth(82);
    obj.label1:setText("Ferramentas:");
    obj.label1:setFontColor("#C9A45C");
    lfm_setPropAsString(obj.label1, "fontStyle", "bold");
    obj.label1:setName("label1");

    obj.button11 = GUI.fromHandle(_obj_newObject("button"));
    obj.button11:setParent(obj.layout2);
    obj.button11:setAlign("left");
    obj.button11:setWidth(75);
    obj.button11:setText("Favoritos");
    obj.button11:setName("button11");

    obj.button12 = GUI.fromHandle(_obj_newObject("button"));
    obj.button12:setParent(obj.layout2);
    obj.button12:setAlign("left");
    obj.button12:setWidth(62);
    obj.button12:setText("Areas");
    obj.button12:setName("button12");

    obj.button13 = GUI.fromHandle(_obj_newObject("button"));
    obj.button13:setParent(obj.layout2);
    obj.button13:setAlign("left");
    obj.button13:setWidth(72);
    obj.button13:setText("Loot");
    obj.button13:setName("button13");

    obj.button14 = GUI.fromHandle(_obj_newObject("button"));
    obj.button14:setParent(obj.layout2);
    obj.button14:setAlign("left");
    obj.button14:setWidth(78);
    obj.button14:setText("Crafting");
    obj.button14:setName("button14");

    obj.button15 = GUI.fromHandle(_obj_newObject("button"));
    obj.button15:setParent(obj.layout2);
    obj.button15:setAlign("left");
    obj.button15:setWidth(75);
    obj.button15:setText("Tabelas");
    obj.button15:setName("button15");

    obj.layout3 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout3:setParent(obj);
    obj.layout3:setAlign("top");
    obj.layout3:setHeight(34);
    obj.layout3:setMargins({left=88, top=0, right=6, bottom=0});
    obj.layout3:setName("layout3");

    obj.button16 = GUI.fromHandle(_obj_newObject("button"));
    obj.button16:setParent(obj.layout3);
    obj.button16:setAlign("left");
    obj.button16:setWidth(85);
    obj.button16:setText("Encontros");
    obj.button16:setName("button16");

    obj.button17 = GUI.fromHandle(_obj_newObject("button"));
    obj.button17:setParent(obj.layout3);
    obj.button17:setAlign("left");
    obj.button17:setWidth(82);
    obj.button17:setText("Atributos");
    obj.button17:setName("button17");

    obj.button18 = GUI.fromHandle(_obj_newObject("button"));
    obj.button18:setParent(obj.layout3);
    obj.button18:setAlign("left");
    obj.button18:setWidth(55);
    obj.button18:setText("CR");
    obj.button18:setName("button18");

    obj.button19 = GUI.fromHandle(_obj_newObject("button"));
    obj.button19:setParent(obj.layout3);
    obj.button19:setAlign("left");
    obj.button19:setWidth(105);
    obj.button19:setText("Ref. Rapida");
    obj.button19:setName("button19");

    obj.pnlBrowser = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlBrowser:setParent(obj);
    obj.pnlBrowser:setName("pnlBrowser");
    obj.pnlBrowser:setAlign("client");
    obj.pnlBrowser:setMargins({left=8, top=8, right=8, bottom=8});

    obj.layout4 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout4:setParent(obj.pnlBrowser);
    obj.layout4:setAlign("top");
    obj.layout4:setHeight(48);
    obj.layout4:setName("layout4");

    obj.lblSection = GUI.fromHandle(_obj_newObject("label"));
    obj.lblSection:setParent(obj.layout4);
    obj.lblSection:setName("lblSection");
    obj.lblSection:setAlign("left");
    obj.lblSection:setWidth(145);
    obj.lblSection:setText("Compendio");
    obj.lblSection:setFontSize(19);
    lfm_setPropAsString(obj.lblSection, "fontStyle", "bold");
    obj.lblSection:setFontColor("#FFFFFF");

    obj.edtSearch = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtSearch:setParent(obj.layout4);
    obj.edtSearch:setName("edtSearch");
    obj.edtSearch:setAlign("client");
    obj.edtSearch:setHint("Buscar nesta secao...");
    obj.edtSearch:setMargins({left=6, top=0, right=6, bottom=0});

    obj.button20 = GUI.fromHandle(_obj_newObject("button"));
    obj.button20:setParent(obj.layout4);
    obj.button20:setAlign("right");
    obj.button20:setWidth(75);
    obj.button20:setText("Buscar");
    obj.button20:setName("button20");

    obj.button21 = GUI.fromHandle(_obj_newObject("button"));
    obj.button21:setParent(obj.layout4);
    obj.button21:setAlign("right");
    obj.button21:setWidth(75);
    obj.button21:setText("Limpar");
    obj.button21:setName("button21");

    obj.pnlReferenceNav = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlReferenceNav:setParent(obj.pnlBrowser);
    obj.pnlReferenceNav:setName("pnlReferenceNav");
    obj.pnlReferenceNav:setAlign("top");
    obj.pnlReferenceNav:setHeight(68);
    obj.pnlReferenceNav:setVisible(false);

    obj.layout5 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout5:setParent(obj.pnlReferenceNav);
    obj.layout5:setAlign("top");
    obj.layout5:setHeight(34);
    obj.layout5:setMargins({left=6, top=2, right=6, bottom=0});
    obj.layout5:setName("layout5");

    obj.label2 = GUI.fromHandle(_obj_newObject("label"));
    obj.label2:setParent(obj.layout5);
    obj.label2:setAlign("left");
    obj.label2:setWidth(82);
    obj.label2:setText("Compendio:");
    obj.label2:setFontColor("#C9A45C");
    lfm_setPropAsString(obj.label2, "fontStyle", "bold");
    obj.label2:setName("label2");

    obj.button22 = GUI.fromHandle(_obj_newObject("button"));
    obj.button22:setParent(obj.layout5);
    obj.button22:setAlign("left");
    obj.button22:setWidth(125);
    obj.button22:setText("Opcoes e Features");
    obj.button22:setName("button22");

    obj.button23 = GUI.fromHandle(_obj_newObject("button"));
    obj.button23:setParent(obj.layout5);
    obj.button23:setAlign("left");
    obj.button23:setWidth(105);
    obj.button23:setText("Backgrounds");
    obj.button23:setName("button23");

    obj.button24 = GUI.fromHandle(_obj_newObject("button"));
    obj.button24:setParent(obj.layout5);
    obj.button24:setAlign("left");
    obj.button24:setWidth(138);
    obj.button24:setText("Opcoes de Personagem");
    obj.button24:setName("button24");

    obj.button25 = GUI.fromHandle(_obj_newObject("button"));
    obj.button25:setParent(obj.layout5);
    obj.button25:setAlign("left");
    obj.button25:setWidth(72);
    obj.button25:setText("Acoes");
    obj.button25:setName("button25");

    obj.button26 = GUI.fromHandle(_obj_newObject("button"));
    obj.button26:setParent(obj.layout5);
    obj.button26:setAlign("left");
    obj.button26:setWidth(105);
    obj.button26:setText("Recompensas");
    obj.button26:setName("button26");

    obj.layout6 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout6:setParent(obj.pnlReferenceNav);
    obj.layout6:setAlign("top");
    obj.layout6:setHeight(34);
    obj.layout6:setMargins({left=88, top=0, right=6, bottom=0});
    obj.layout6:setName("layout6");

    obj.button27 = GUI.fromHandle(_obj_newObject("button"));
    obj.button27:setParent(obj.layout6);
    obj.button27:setAlign("left");
    obj.button27:setWidth(80);
    obj.button27:setText("Objetos");
    obj.button27:setName("button27");

    obj.button28 = GUI.fromHandle(_obj_newObject("button"));
    obj.button28:setParent(obj.layout6);
    obj.button28:setAlign("left");
    obj.button28:setWidth(135);
    obj.button28:setText("Armadilhas e Perigos");
    obj.button28:setName("button28");

    obj.button29 = GUI.fromHandle(_obj_newObject("button"));
    obj.button29:setParent(obj.layout6);
    obj.button29:setAlign("left");
    obj.button29:setWidth(90);
    obj.button29:setText("Psionicos");
    obj.button29:setName("button29");

    obj.button30 = GUI.fromHandle(_obj_newObject("button"));
    obj.button30:setParent(obj.layout6);
    obj.button30:setAlign("left");
    obj.button30:setWidth(90);
    obj.button30:setText("Veiculos");
    obj.button30:setName("button30");

    obj.pnlCommonFilters = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlCommonFilters:setParent(obj.pnlBrowser);
    obj.pnlCommonFilters:setName("pnlCommonFilters");
    obj.pnlCommonFilters:setAlign("top");
    obj.pnlCommonFilters:setHeight(38);
    obj.pnlCommonFilters:setMargins({left=0, top=2, right=0, bottom=2});

    obj.label3 = GUI.fromHandle(_obj_newObject("label"));
    obj.label3:setParent(obj.pnlCommonFilters);
    obj.label3:setAlign("left");
    obj.label3:setWidth(45);
    obj.label3:setText("Livro");
    obj.label3:setFontColor("#DDDDDD");
    obj.label3:setName("label3");

    obj.cmbSource = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbSource:setParent(obj.pnlCommonFilters);
    obj.cmbSource:setName("cmbSource");
    obj.cmbSource:setAlign("left");
    obj.cmbSource:setWidth(150);
    obj.cmbSource:setItems({'Todos os livros'});
    obj.cmbSource:setValues({'all'});
    obj.cmbSource:setValue("all");

    obj.label4 = GUI.fromHandle(_obj_newObject("label"));
    obj.label4:setParent(obj.pnlCommonFilters);
    obj.label4:setAlign("left");
    obj.label4:setWidth(52);
    obj.label4:setText("Edicao");
    obj.label4:setFontColor("#DDDDDD");
    obj.label4:setName("label4");

    obj.cmbEdition = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbEdition:setParent(obj.pnlCommonFilters);
    obj.cmbEdition:setName("cmbEdition");
    obj.cmbEdition:setAlign("left");
    obj.cmbEdition:setWidth(82);
    obj.cmbEdition:setItems({'Todas','2014','2024'});
    obj.cmbEdition:setValues({'all','2014','2024'});
    obj.cmbEdition:setValue("all");

    obj.label5 = GUI.fromHandle(_obj_newObject("label"));
    obj.label5:setParent(obj.pnlCommonFilters);
    obj.label5:setAlign("left");
    obj.label5:setWidth(62);
    obj.label5:setText("Origem");
    obj.label5:setFontColor("#DDDDDD");
    obj.label5:setName("label5");

    obj.cmbOrigin = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbOrigin:setParent(obj.pnlCommonFilters);
    obj.cmbOrigin:setName("cmbOrigin");
    obj.cmbOrigin:setAlign("left");
    obj.cmbOrigin:setWidth(105);
    obj.cmbOrigin:setItems({'Todos','Principal','Homebrew'});
    obj.cmbOrigin:setValues({'all','core','homebrew'});
    obj.cmbOrigin:setValue("all");

    obj.lblCount = GUI.fromHandle(_obj_newObject("label"));
    obj.lblCount:setParent(obj.pnlCommonFilters);
    obj.lblCount:setName("lblCount");
    obj.lblCount:setAlign("right");
    obj.lblCount:setWidth(145);
    obj.lblCount:setText("Escolha uma secao");
    obj.lblCount:setHorzTextAlign("trailing");
    obj.lblCount:setFontColor("#AAAAAA");

    obj.pnlSpellFilters = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlSpellFilters:setParent(obj.pnlBrowser);
    obj.pnlSpellFilters:setName("pnlSpellFilters");
    obj.pnlSpellFilters:setAlign("top");
    obj.pnlSpellFilters:setHeight(38);
    obj.pnlSpellFilters:setVisible(false);
    obj.pnlSpellFilters:setMargins({left=0, top=2, right=0, bottom=2});

    obj.label6 = GUI.fromHandle(_obj_newObject("label"));
    obj.label6:setParent(obj.pnlSpellFilters);
    obj.label6:setAlign("left");
    obj.label6:setWidth(42);
    obj.label6:setText("Nivel");
    obj.label6:setFontColor("#DDDDDD");
    obj.label6:setName("label6");

    obj.cmbLevel = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbLevel:setParent(obj.pnlSpellFilters);
    obj.cmbLevel:setName("cmbLevel");
    obj.cmbLevel:setAlign("left");
    obj.cmbLevel:setWidth(105);
    obj.cmbLevel:setItems({'Todos niveis'});
    obj.cmbLevel:setValues({'all'});
    obj.cmbLevel:setValue("all");

    obj.label7 = GUI.fromHandle(_obj_newObject("label"));
    obj.label7:setParent(obj.pnlSpellFilters);
    obj.label7:setAlign("left");
    obj.label7:setWidth(48);
    obj.label7:setText("Escola");
    obj.label7:setFontColor("#DDDDDD");
    obj.label7:setName("label7");

    obj.cmbSchool = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbSchool:setParent(obj.pnlSpellFilters);
    obj.cmbSchool:setName("cmbSchool");
    obj.cmbSchool:setAlign("left");
    obj.cmbSchool:setWidth(125);
    obj.cmbSchool:setItems({'Todas escolas'});
    obj.cmbSchool:setValues({'all'});
    obj.cmbSchool:setValue("all");

    obj.label8 = GUI.fromHandle(_obj_newObject("label"));
    obj.label8:setParent(obj.pnlSpellFilters);
    obj.label8:setAlign("left");
    obj.label8:setWidth(45);
    obj.label8:setText("Classe");
    obj.label8:setFontColor("#DDDDDD");
    obj.label8:setName("label8");

    obj.cmbSpellClass = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbSpellClass:setParent(obj.pnlSpellFilters);
    obj.cmbSpellClass:setName("cmbSpellClass");
    obj.cmbSpellClass:setAlign("left");
    obj.cmbSpellClass:setWidth(135);
    obj.cmbSpellClass:setItems({'Todas classes'});
    obj.cmbSpellClass:setValues({'all'});
    obj.cmbSpellClass:setValue("all");

    obj.chkRitual = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkRitual:setParent(obj.pnlSpellFilters);
    obj.chkRitual:setName("chkRitual");
    obj.chkRitual:setAlign("left");
    obj.chkRitual:setWidth(72);
    obj.chkRitual:setText("Ritual");

    obj.chkConc = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkConc:setParent(obj.pnlSpellFilters);
    obj.chkConc:setName("chkConc");
    obj.chkConc:setAlign("left");
    obj.chkConc:setWidth(112);
    obj.chkConc:setText("Concentracao");

    obj.pnlCreatureFilters = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlCreatureFilters:setParent(obj.pnlBrowser);
    obj.pnlCreatureFilters:setName("pnlCreatureFilters");
    obj.pnlCreatureFilters:setAlign("top");
    obj.pnlCreatureFilters:setHeight(38);
    obj.pnlCreatureFilters:setVisible(false);
    obj.pnlCreatureFilters:setMargins({left=0, top=2, right=0, bottom=2});

    obj.label9 = GUI.fromHandle(_obj_newObject("label"));
    obj.label9:setParent(obj.pnlCreatureFilters);
    obj.label9:setAlign("left");
    obj.label9:setWidth(28);
    obj.label9:setText("CR");
    obj.label9:setFontColor("#DDDDDD");
    obj.label9:setName("label9");

    obj.cmbCR = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbCR:setParent(obj.pnlCreatureFilters);
    obj.cmbCR:setName("cmbCR");
    obj.cmbCR:setAlign("left");
    obj.cmbCR:setWidth(105);
    obj.cmbCR:setItems({'Todos CR'});
    obj.cmbCR:setValues({'all'});
    obj.cmbCR:setValue("all");

    obj.label10 = GUI.fromHandle(_obj_newObject("label"));
    obj.label10:setParent(obj.pnlCreatureFilters);
    obj.label10:setAlign("left");
    obj.label10:setWidth(38);
    obj.label10:setText("Tipo");
    obj.label10:setFontColor("#DDDDDD");
    obj.label10:setName("label10");

    obj.cmbCreatureType = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbCreatureType:setParent(obj.pnlCreatureFilters);
    obj.cmbCreatureType:setName("cmbCreatureType");
    obj.cmbCreatureType:setAlign("left");
    obj.cmbCreatureType:setWidth(145);
    obj.cmbCreatureType:setItems({'Todos tipos'});
    obj.cmbCreatureType:setValues({'all'});
    obj.cmbCreatureType:setValue("all");

    obj.label11 = GUI.fromHandle(_obj_newObject("label"));
    obj.label11:setParent(obj.pnlCreatureFilters);
    obj.label11:setAlign("left");
    obj.label11:setWidth(62);
    obj.label11:setText("Tamanho");
    obj.label11:setFontColor("#DDDDDD");
    obj.label11:setName("label11");

    obj.cmbSize = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbSize:setParent(obj.pnlCreatureFilters);
    obj.cmbSize:setName("cmbSize");
    obj.cmbSize:setAlign("left");
    obj.cmbSize:setWidth(125);
    obj.cmbSize:setItems({'Todos tamanhos'});
    obj.cmbSize:setValues({'all'});
    obj.cmbSize:setValue("all");

    obj.pnlItemFilters = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlItemFilters:setParent(obj.pnlBrowser);
    obj.pnlItemFilters:setName("pnlItemFilters");
    obj.pnlItemFilters:setAlign("top");
    obj.pnlItemFilters:setHeight(38);
    obj.pnlItemFilters:setVisible(false);
    obj.pnlItemFilters:setMargins({left=0, top=2, right=0, bottom=2});

    obj.label12 = GUI.fromHandle(_obj_newObject("label"));
    obj.label12:setParent(obj.pnlItemFilters);
    obj.label12:setAlign("left");
    obj.label12:setWidth(38);
    obj.label12:setText("Tipo");
    obj.label12:setFontColor("#DDDDDD");
    obj.label12:setName("label12");

    obj.chkWeapon = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkWeapon:setParent(obj.pnlItemFilters);
    obj.chkWeapon:setName("chkWeapon");
    obj.chkWeapon:setAlign("left");
    obj.chkWeapon:setWidth(66);
    obj.chkWeapon:setText("Arma");

    obj.chkArmor = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkArmor:setParent(obj.pnlItemFilters);
    obj.chkArmor:setName("chkArmor");
    obj.chkArmor:setAlign("left");
    obj.chkArmor:setWidth(78);
    obj.chkArmor:setText("Armadura");

    obj.chkGear = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkGear:setParent(obj.pnlItemFilters);
    obj.chkGear:setName("chkGear");
    obj.chkGear:setAlign("left");
    obj.chkGear:setWidth(92);
    obj.chkGear:setText("Equipamento");

    obj.chkOtherType = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkOtherType:setParent(obj.pnlItemFilters);
    obj.chkOtherType:setName("chkOtherType");
    obj.chkOtherType:setAlign("left");
    obj.chkOtherType:setWidth(68);
    obj.chkOtherType:setText("Outros");

    obj.cmbItemType = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbItemType:setParent(obj.pnlItemFilters);
    obj.cmbItemType:setName("cmbItemType");
    obj.cmbItemType:setVisible(false);
    obj.cmbItemType:setItems({'Todos tipos'});
    obj.cmbItemType:setValues({'all'});
    obj.cmbItemType:setValue("all");

    obj.lblRarity = GUI.fromHandle(_obj_newObject("label"));
    obj.lblRarity:setParent(obj.pnlItemFilters);
    obj.lblRarity:setName("lblRarity");
    obj.lblRarity:setAlign("left");
    obj.lblRarity:setWidth(62);
    obj.lblRarity:setText("Raridade");
    obj.lblRarity:setFontColor("#DDDDDD");

    obj.cmbRarity = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbRarity:setParent(obj.pnlItemFilters);
    obj.cmbRarity:setName("cmbRarity");
    obj.cmbRarity:setVisible(false);
    obj.cmbRarity:setItems({'Todas raridades'});
    obj.cmbRarity:setValues({'all'});
    obj.cmbRarity:setValue("all");

    obj.lblAttune = GUI.fromHandle(_obj_newObject("label"));
    obj.lblAttune:setParent(obj.pnlItemFilters);
    obj.lblAttune:setName("lblAttune");
    obj.lblAttune:setAlign("left");
    obj.lblAttune:setWidth(82);
    obj.lblAttune:setText("Sintonizacao");
    obj.lblAttune:setFontColor("#DDDDDD");

    obj.cmbAttune = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbAttune:setParent(obj.pnlItemFilters);
    obj.cmbAttune:setName("cmbAttune");
    obj.cmbAttune:setAlign("left");
    obj.cmbAttune:setWidth(100);
    obj.cmbAttune:setItems({'Todas','Sim','Nao'});
    obj.cmbAttune:setValues({'all','yes','no'});
    obj.cmbAttune:setValue("all");

    obj.pnlRarityChecks = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlRarityChecks:setParent(obj.pnlBrowser);
    obj.pnlRarityChecks:setName("pnlRarityChecks");
    obj.pnlRarityChecks:setAlign("top");
    obj.pnlRarityChecks:setHeight(34);
    obj.pnlRarityChecks:setVisible(false);
    obj.pnlRarityChecks:setMargins({left=0, top=0, right=0, bottom=2});

    obj.label13 = GUI.fromHandle(_obj_newObject("label"));
    obj.label13:setParent(obj.pnlRarityChecks);
    obj.label13:setAlign("left");
    obj.label13:setWidth(62);
    obj.label13:setText("Raridade");
    obj.label13:setFontColor("#DDDDDD");
    obj.label13:setName("label13");

    obj.chkCommon = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkCommon:setParent(obj.pnlRarityChecks);
    obj.chkCommon:setName("chkCommon");
    obj.chkCommon:setAlign("left");
    obj.chkCommon:setWidth(65);
    obj.chkCommon:setText("Comum");

    obj.chkUncommon = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkUncommon:setParent(obj.pnlRarityChecks);
    obj.chkUncommon:setName("chkUncommon");
    obj.chkUncommon:setAlign("left");
    obj.chkUncommon:setWidth(78);
    obj.chkUncommon:setText("Incomum");

    obj.chkRare = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkRare:setParent(obj.pnlRarityChecks);
    obj.chkRare:setName("chkRare");
    obj.chkRare:setAlign("left");
    obj.chkRare:setWidth(55);
    obj.chkRare:setText("Raro");

    obj.chkVeryRare = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkVeryRare:setParent(obj.pnlRarityChecks);
    obj.chkVeryRare:setName("chkVeryRare");
    obj.chkVeryRare:setAlign("left");
    obj.chkVeryRare:setWidth(92);
    obj.chkVeryRare:setText("Muito raro");

    obj.chkLegendary = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkLegendary:setParent(obj.pnlRarityChecks);
    obj.chkLegendary:setName("chkLegendary");
    obj.chkLegendary:setAlign("left");
    obj.chkLegendary:setWidth(80);
    obj.chkLegendary:setText("Lendario");

    obj.chkArtifact = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkArtifact:setParent(obj.pnlRarityChecks);
    obj.chkArtifact:setName("chkArtifact");
    obj.chkArtifact:setAlign("left");
    obj.chkArtifact:setWidth(72);
    obj.chkArtifact:setText("Artefato");

    obj.layout7 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout7:setParent(obj.pnlBrowser);
    obj.layout7:setAlign("client");
    obj.layout7:setName("layout7");

    obj.layout8 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout8:setParent(obj.layout7);
    obj.layout8:setAlign("left");
    obj.layout8:setWidth(365);
    obj.layout8:setMargins({left=0, top=0, right=10, bottom=0});
    obj.layout8:setName("layout8");

    obj.row1 = GUI.fromHandle(_obj_newObject("button"));
    obj.row1:setParent(obj.layout8);
    obj.row1:setName("row1");
    obj.row1:setAlign("top");
    obj.row1:setHeight(34);
    obj.row1:setText("");
    obj.row1:setVisible(false);

    obj.row2 = GUI.fromHandle(_obj_newObject("button"));
    obj.row2:setParent(obj.layout8);
    obj.row2:setName("row2");
    obj.row2:setAlign("top");
    obj.row2:setHeight(34);
    obj.row2:setText("");
    obj.row2:setVisible(false);

    obj.row3 = GUI.fromHandle(_obj_newObject("button"));
    obj.row3:setParent(obj.layout8);
    obj.row3:setName("row3");
    obj.row3:setAlign("top");
    obj.row3:setHeight(34);
    obj.row3:setText("");
    obj.row3:setVisible(false);

    obj.row4 = GUI.fromHandle(_obj_newObject("button"));
    obj.row4:setParent(obj.layout8);
    obj.row4:setName("row4");
    obj.row4:setAlign("top");
    obj.row4:setHeight(34);
    obj.row4:setText("");
    obj.row4:setVisible(false);

    obj.row5 = GUI.fromHandle(_obj_newObject("button"));
    obj.row5:setParent(obj.layout8);
    obj.row5:setName("row5");
    obj.row5:setAlign("top");
    obj.row5:setHeight(34);
    obj.row5:setText("");
    obj.row5:setVisible(false);

    obj.row6 = GUI.fromHandle(_obj_newObject("button"));
    obj.row6:setParent(obj.layout8);
    obj.row6:setName("row6");
    obj.row6:setAlign("top");
    obj.row6:setHeight(34);
    obj.row6:setText("");
    obj.row6:setVisible(false);

    obj.row7 = GUI.fromHandle(_obj_newObject("button"));
    obj.row7:setParent(obj.layout8);
    obj.row7:setName("row7");
    obj.row7:setAlign("top");
    obj.row7:setHeight(34);
    obj.row7:setText("");
    obj.row7:setVisible(false);

    obj.row8 = GUI.fromHandle(_obj_newObject("button"));
    obj.row8:setParent(obj.layout8);
    obj.row8:setName("row8");
    obj.row8:setAlign("top");
    obj.row8:setHeight(34);
    obj.row8:setText("");
    obj.row8:setVisible(false);

    obj.row9 = GUI.fromHandle(_obj_newObject("button"));
    obj.row9:setParent(obj.layout8);
    obj.row9:setName("row9");
    obj.row9:setAlign("top");
    obj.row9:setHeight(34);
    obj.row9:setText("");
    obj.row9:setVisible(false);

    obj.row10 = GUI.fromHandle(_obj_newObject("button"));
    obj.row10:setParent(obj.layout8);
    obj.row10:setName("row10");
    obj.row10:setAlign("top");
    obj.row10:setHeight(34);
    obj.row10:setText("");
    obj.row10:setVisible(false);

    obj.row11 = GUI.fromHandle(_obj_newObject("button"));
    obj.row11:setParent(obj.layout8);
    obj.row11:setName("row11");
    obj.row11:setAlign("top");
    obj.row11:setHeight(34);
    obj.row11:setText("");
    obj.row11:setVisible(false);

    obj.row12 = GUI.fromHandle(_obj_newObject("button"));
    obj.row12:setParent(obj.layout8);
    obj.row12:setName("row12");
    obj.row12:setAlign("top");
    obj.row12:setHeight(34);
    obj.row12:setText("");
    obj.row12:setVisible(false);

    obj.row13 = GUI.fromHandle(_obj_newObject("button"));
    obj.row13:setParent(obj.layout8);
    obj.row13:setName("row13");
    obj.row13:setAlign("top");
    obj.row13:setHeight(34);
    obj.row13:setText("");
    obj.row13:setVisible(false);

    obj.row14 = GUI.fromHandle(_obj_newObject("button"));
    obj.row14:setParent(obj.layout8);
    obj.row14:setName("row14");
    obj.row14:setAlign("top");
    obj.row14:setHeight(34);
    obj.row14:setText("");
    obj.row14:setVisible(false);

    obj.row15 = GUI.fromHandle(_obj_newObject("button"));
    obj.row15:setParent(obj.layout8);
    obj.row15:setName("row15");
    obj.row15:setAlign("top");
    obj.row15:setHeight(34);
    obj.row15:setText("");
    obj.row15:setVisible(false);

    obj.layout9 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout9:setParent(obj.layout7);
    obj.layout9:setAlign("client");
    obj.layout9:setName("layout9");

    obj.rectangle2 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle2:setParent(obj.layout9);
    obj.rectangle2:setAlign("top");
    obj.rectangle2:setHeight(3);
    obj.rectangle2:setColor("#C9A45C");
    obj.rectangle2:setName("rectangle2");

    obj.pnlCreatureTabs = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlCreatureTabs:setParent(obj.layout9);
    obj.pnlCreatureTabs:setName("pnlCreatureTabs");
    obj.pnlCreatureTabs:setAlign("top");
    obj.pnlCreatureTabs:setHeight(30);
    obj.pnlCreatureTabs:setVisible(false);

    obj.button31 = GUI.fromHandle(_obj_newObject("button"));
    obj.button31:setParent(obj.pnlCreatureTabs);
    obj.button31:setAlign("left");
    obj.button31:setWidth(55);
    obj.button31:setText("Tudo");
    obj.button31:setName("button31");

    obj.button32 = GUI.fromHandle(_obj_newObject("button"));
    obj.button32:setParent(obj.pnlCreatureTabs);
    obj.button32:setAlign("left");
    obj.button32:setWidth(75);
    obj.button32:setText("Stats");
    obj.button32:setName("button32");

    obj.button33 = GUI.fromHandle(_obj_newObject("button"));
    obj.button33:setParent(obj.pnlCreatureTabs);
    obj.button33:setAlign("left");
    obj.button33:setWidth(75);
    obj.button33:setText("Tracos");
    obj.button33:setName("button33");

    obj.button34 = GUI.fromHandle(_obj_newObject("button"));
    obj.button34:setParent(obj.pnlCreatureTabs);
    obj.button34:setAlign("left");
    obj.button34:setWidth(75);
    obj.button34:setText("Acoes");
    obj.button34:setName("button34");

    obj.button35 = GUI.fromHandle(_obj_newObject("button"));
    obj.button35:setParent(obj.pnlCreatureTabs);
    obj.button35:setAlign("left");
    obj.button35:setWidth(70);
    obj.button35:setText("Bonus");
    obj.button35:setName("button35");

    obj.button36 = GUI.fromHandle(_obj_newObject("button"));
    obj.button36:setParent(obj.pnlCreatureTabs);
    obj.button36:setAlign("left");
    obj.button36:setWidth(75);
    obj.button36:setText("Reacoes");
    obj.button36:setName("button36");

    obj.button37 = GUI.fromHandle(_obj_newObject("button"));
    obj.button37:setParent(obj.pnlCreatureTabs);
    obj.button37:setAlign("left");
    obj.button37:setWidth(85);
    obj.button37:setText("Lendarias");
    obj.button37:setName("button37");

    obj.btnFavorite = GUI.fromHandle(_obj_newObject("button"));
    obj.btnFavorite:setParent(obj.layout9);
    obj.btnFavorite:setName("btnFavorite");
    obj.btnFavorite:setAlign("top");
    obj.btnFavorite:setHeight(28);
    obj.btnFavorite:setText("☆ Favoritar");

    obj.btnCraft = GUI.fromHandle(_obj_newObject("button"));
    obj.btnCraft:setParent(obj.layout9);
    obj.btnCraft:setName("btnCraft");
    obj.btnCraft:setAlign("top");
    obj.btnCraft:setHeight(28);
    obj.btnCraft:setText("Calcular crafting");

    obj.lblTitle = GUI.fromHandle(_obj_newObject("label"));
    obj.lblTitle:setParent(obj.layout9);
    obj.lblTitle:setName("lblTitle");
    obj.lblTitle:setAlign("top");
    obj.lblTitle:setHeight(38);
    obj.lblTitle:setText("Compendio");
    obj.lblTitle:setFontSize(21);
    lfm_setPropAsString(obj.lblTitle, "fontStyle", "bold");
    obj.lblTitle:setFontColor("#FFFFFF");

    obj.lblSub = GUI.fromHandle(_obj_newObject("label"));
    obj.lblSub:setParent(obj.layout9);
    obj.lblSub:setName("lblSub");
    obj.lblSub:setAlign("top");
    obj.lblSub:setHeight(28);
    obj.lblSub:setText("Escolha uma secao.");
    obj.lblSub:setFontColor("#AAAAAA");

    obj.txtDetails = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.txtDetails:setParent(obj.layout9);
    obj.txtDetails:setName("txtDetails");
    obj.txtDetails:setAlign("client");
    obj.txtDetails:setReadOnly(true);
    obj.txtDetails:setText("");
    obj.txtDetails:setFontColor("#EEEEEE");

    obj.layout10 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout10:setParent(obj.pnlBrowser);
    obj.layout10:setAlign("bottom");
    obj.layout10:setHeight(36);
    obj.layout10:setName("layout10");

    obj.button38 = GUI.fromHandle(_obj_newObject("button"));
    obj.button38:setParent(obj.layout10);
    obj.button38:setAlign("left");
    obj.button38:setWidth(90);
    obj.button38:setText("Anterior");
    obj.button38:setName("button38");

    obj.lblPage = GUI.fromHandle(_obj_newObject("label"));
    obj.lblPage:setParent(obj.layout10);
    obj.lblPage:setName("lblPage");
    obj.lblPage:setAlign("client");
    obj.lblPage:setText("Pagina 1 / 1");
    obj.lblPage:setHorzTextAlign("center");
    obj.lblPage:setFontColor("#C9A45C");
    lfm_setPropAsString(obj.lblPage, "fontStyle", "bold");

    obj.button39 = GUI.fromHandle(_obj_newObject("button"));
    obj.button39:setParent(obj.layout10);
    obj.button39:setAlign("right");
    obj.button39:setWidth(90);
    obj.button39:setText("Proxima");
    obj.button39:setName("button39");

    obj.pnlCR = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlCR:setParent(obj);
    obj.pnlCR:setName("pnlCR");
    obj.pnlCR:setAlign("client");
    obj.pnlCR:setVisible(false);
    obj.pnlCR:setMargins({left=18, top=18, right=18, bottom=18});

    obj.label14 = GUI.fromHandle(_obj_newObject("label"));
    obj.label14:setParent(obj.pnlCR);
    obj.label14:setAlign("top");
    obj.label14:setHeight(38);
    obj.label14:setText("Calculadora de CR (2014)");
    obj.label14:setFontSize(22);
    lfm_setPropAsString(obj.label14, "fontStyle", "bold");
    obj.label14:setFontColor("#FFFFFF");
    obj.label14:setName("label14");

    obj.layout11 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout11:setParent(obj.pnlCR);
    obj.layout11:setAlign("top");
    obj.layout11:setHeight(40);
    obj.layout11:setName("layout11");

    obj.label15 = GUI.fromHandle(_obj_newObject("label"));
    obj.label15:setParent(obj.layout11);
    obj.label15:setAlign("left");
    obj.label15:setWidth(28);
    obj.label15:setText("PV");
    obj.label15:setFontColor("#FFFFFF");
    obj.label15:setName("label15");

    obj.edtCRHP = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtCRHP:setParent(obj.layout11);
    obj.edtCRHP:setName("edtCRHP");
    obj.edtCRHP:setAlign("left");
    obj.edtCRHP:setWidth(65);
    obj.edtCRHP:setText("71");

    obj.label16 = GUI.fromHandle(_obj_newObject("label"));
    obj.label16:setParent(obj.layout11);
    obj.label16:setAlign("left");
    obj.label16:setWidth(28);
    obj.label16:setText("CA");
    obj.label16:setFontColor("#FFFFFF");
    obj.label16:setName("label16");

    obj.edtCRAC = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtCRAC:setParent(obj.layout11);
    obj.edtCRAC:setName("edtCRAC");
    obj.edtCRAC:setAlign("left");
    obj.edtCRAC:setWidth(55);
    obj.edtCRAC:setText("13");

    obj.label17 = GUI.fromHandle(_obj_newObject("label"));
    obj.label17:setParent(obj.layout11);
    obj.label17:setAlign("left");
    obj.label17:setWidth(92);
    obj.label17:setText("Dano/rodada");
    obj.label17:setFontColor("#FFFFFF");
    obj.label17:setName("label17");

    obj.edtCRDPR = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtCRDPR:setParent(obj.layout11);
    obj.edtCRDPR:setName("edtCRDPR");
    obj.edtCRDPR:setAlign("left");
    obj.edtCRDPR:setWidth(60);
    obj.edtCRDPR:setText("9");

    obj.layout12 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout12:setParent(obj.pnlCR);
    obj.layout12:setAlign("top");
    obj.layout12:setHeight(40);
    obj.layout12:setName("layout12");

    obj.label18 = GUI.fromHandle(_obj_newObject("label"));
    obj.label18:setParent(obj.layout12);
    obj.label18:setAlign("left");
    obj.label18:setWidth(55);
    obj.label18:setText("Ataque");
    obj.label18:setFontColor("#FFFFFF");
    obj.label18:setName("label18");

    obj.edtCRAttack = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtCRAttack:setParent(obj.layout12);
    obj.edtCRAttack:setName("edtCRAttack");
    obj.edtCRAttack:setAlign("left");
    obj.edtCRAttack:setWidth(55);
    obj.edtCRAttack:setText("3");

    obj.label19 = GUI.fromHandle(_obj_newObject("label"));
    obj.label19:setParent(obj.layout12);
    obj.label19:setAlign("left");
    obj.label19:setWidth(30);
    obj.label19:setText("CD");
    obj.label19:setFontColor("#FFFFFF");
    obj.label19:setName("label19");

    obj.edtCRDC = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtCRDC:setParent(obj.layout12);
    obj.edtCRDC:setName("edtCRDC");
    obj.edtCRDC:setAlign("left");
    obj.edtCRDC:setWidth(55);
    obj.edtCRDC:setText("13");

    obj.chkCRSave = GUI.fromHandle(_obj_newObject("checkBox"));
    obj.chkCRSave:setParent(obj.layout12);
    obj.chkCRSave:setName("chkCRSave");
    obj.chkCRSave:setAlign("left");
    obj.chkCRSave:setWidth(105);
    obj.chkCRSave:setText("Usar CD");

    obj.button40 = GUI.fromHandle(_obj_newObject("button"));
    obj.button40:setParent(obj.layout12);
    obj.button40:setAlign("left");
    obj.button40:setWidth(100);
    obj.button40:setText("Calcular");
    obj.button40:setName("button40");

    obj.txtCR = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.txtCR:setParent(obj.pnlCR);
    obj.txtCR:setName("txtCR");
    obj.txtCR:setAlign("client");
    obj.txtCR:setReadOnly(true);
    obj.txtCR:setFontColor("#EEEEEE");

    obj.pnlStats = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlStats:setParent(obj);
    obj.pnlStats:setName("pnlStats");
    obj.pnlStats:setAlign("client");
    obj.pnlStats:setVisible(false);
    obj.pnlStats:setMargins({left=18, top=18, right=18, bottom=18});

    obj.label20 = GUI.fromHandle(_obj_newObject("label"));
    obj.label20:setParent(obj.pnlStats);
    obj.label20:setAlign("top");
    obj.label20:setHeight(38);
    obj.label20:setText("Gerador de Atributos");
    obj.label20:setFontSize(22);
    lfm_setPropAsString(obj.label20, "fontStyle", "bold");
    obj.label20:setFontColor("#FFFFFF");
    obj.label20:setName("label20");

    obj.layout13 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout13:setParent(obj.pnlStats);
    obj.layout13:setAlign("top");
    obj.layout13:setHeight(42);
    obj.layout13:setName("layout13");

    obj.button41 = GUI.fromHandle(_obj_newObject("button"));
    obj.button41:setParent(obj.layout13);
    obj.button41:setAlign("left");
    obj.button41:setWidth(115);
    obj.button41:setText("Standard Array");
    obj.button41:setName("button41");

    obj.button42 = GUI.fromHandle(_obj_newObject("button"));
    obj.button42:setParent(obj.layout13);
    obj.button42:setAlign("left");
    obj.button42:setWidth(95);
    obj.button42:setText("Point Buy");
    obj.button42:setName("button42");

    obj.label21 = GUI.fromHandle(_obj_newObject("label"));
    obj.label21:setParent(obj.layout13);
    obj.label21:setAlign("left");
    obj.label21:setWidth(45);
    obj.label21:setText("Dados");
    obj.label21:setFontColor("#FFFFFF");
    obj.label21:setName("label21");

    obj.edtStatDice = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtStatDice:setParent(obj.layout13);
    obj.edtStatDice:setName("edtStatDice");
    obj.edtStatDice:setAlign("left");
    obj.edtStatDice:setWidth(45);
    obj.edtStatDice:setText("4");

    obj.label22 = GUI.fromHandle(_obj_newObject("label"));
    obj.label22:setParent(obj.layout13);
    obj.label22:setAlign("left");
    obj.label22:setWidth(65);
    obj.label22:setText("Descartar");
    obj.label22:setFontColor("#FFFFFF");
    obj.label22:setName("label22");

    obj.edtStatDrop = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtStatDrop:setParent(obj.layout13);
    obj.edtStatDrop:setName("edtStatDrop");
    obj.edtStatDrop:setAlign("left");
    obj.edtStatDrop:setWidth(45);
    obj.edtStatDrop:setText("1");

    obj.button43 = GUI.fromHandle(_obj_newObject("button"));
    obj.button43:setParent(obj.layout13);
    obj.button43:setAlign("left");
    obj.button43:setWidth(90);
    obj.button43:setText("Rolar d6");
    obj.button43:setName("button43");

    obj.txtStats = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.txtStats:setParent(obj.pnlStats);
    obj.txtStats:setName("txtStats");
    obj.txtStats:setAlign("client");
    obj.txtStats:setReadOnly(true);
    obj.txtStats:setFontColor("#EEEEEE");

    obj.pnlEncounters = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlEncounters:setParent(obj);
    obj.pnlEncounters:setName("pnlEncounters");
    obj.pnlEncounters:setAlign("client");
    obj.pnlEncounters:setVisible(false);
    obj.pnlEncounters:setMargins({left=18, top=18, right=18, bottom=18});

    obj.label23 = GUI.fromHandle(_obj_newObject("label"));
    obj.label23:setParent(obj.pnlEncounters);
    obj.label23:setAlign("top");
    obj.label23:setHeight(38);
    obj.label23:setText("Encontros - DMG 2024");
    obj.label23:setFontSize(22);
    lfm_setPropAsString(obj.label23, "fontStyle", "bold");
    obj.label23:setFontColor("#FFFFFF");
    obj.label23:setName("label23");

    obj.layout14 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout14:setParent(obj.pnlEncounters);
    obj.layout14:setAlign("top");
    obj.layout14:setHeight(42);
    obj.layout14:setName("layout14");

    obj.label24 = GUI.fromHandle(_obj_newObject("label"));
    obj.label24:setParent(obj.layout14);
    obj.label24:setAlign("left");
    obj.label24:setWidth(55);
    obj.label24:setText("Tabela");
    obj.label24:setFontColor("#FFFFFF");
    obj.label24:setName("label24");

    obj.cmbEncounterTable = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbEncounterTable:setParent(obj.layout14);
    obj.cmbEncounterTable:setName("cmbEncounterTable");
    obj.cmbEncounterTable:setAlign("left");
    obj.cmbEncounterTable:setWidth(390);
    obj.cmbEncounterTable:setItems({});
    obj.cmbEncounterTable:setValues({});

    obj.button44 = GUI.fromHandle(_obj_newObject("button"));
    obj.button44:setParent(obj.layout14);
    obj.button44:setAlign("left");
    obj.button44:setWidth(90);
    obj.button44:setText("Rolar");
    obj.button44:setName("button44");

    obj.txtEncounter = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.txtEncounter:setParent(obj.pnlEncounters);
    obj.txtEncounter:setName("txtEncounter");
    obj.txtEncounter:setAlign("client");
    obj.txtEncounter:setReadOnly(true);
    obj.txtEncounter:setFontColor("#EEEEEE");

    obj.pnlTables = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlTables:setParent(obj);
    obj.pnlTables:setName("pnlTables");
    obj.pnlTables:setAlign("client");
    obj.pnlTables:setVisible(false);
    obj.pnlTables:setMargins({left=18, top=18, right=18, bottom=18});

    obj.label25 = GUI.fromHandle(_obj_newObject("label"));
    obj.label25:setParent(obj.pnlTables);
    obj.label25:setAlign("top");
    obj.label25:setHeight(38);
    obj.label25:setText("Motor de tabelas");
    obj.label25:setFontSize(22);
    lfm_setPropAsString(obj.label25, "fontStyle", "bold");
    obj.label25:setFontColor("#FFFFFF");
    obj.label25:setName("label25");

    obj.layout15 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout15:setParent(obj.pnlTables);
    obj.layout15:setAlign("top");
    obj.layout15:setHeight(38);
    obj.layout15:setName("layout15");

    obj.label26 = GUI.fromHandle(_obj_newObject("label"));
    obj.label26:setParent(obj.layout15);
    obj.label26:setAlign("left");
    obj.label26:setWidth(45);
    obj.label26:setText("Busca");
    obj.label26:setFontColor("#FFFFFF");
    obj.label26:setName("label26");

    obj.edtTableSearch = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtTableSearch:setParent(obj.layout15);
    obj.edtTableSearch:setName("edtTableSearch");
    obj.edtTableSearch:setAlign("left");
    obj.edtTableSearch:setWidth(180);
    obj.edtTableSearch:setText("");

    obj.label27 = GUI.fromHandle(_obj_newObject("label"));
    obj.label27:setParent(obj.layout15);
    obj.label27:setAlign("left");
    obj.label27:setWidth(45);
    obj.label27:setText("Livro");
    obj.label27:setFontColor("#FFFFFF");
    obj.label27:setName("label27");

    obj.cmbTableBook = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbTableBook:setParent(obj.layout15);
    obj.cmbTableBook:setName("cmbTableBook");
    obj.cmbTableBook:setAlign("left");
    obj.cmbTableBook:setWidth(130);
    obj.cmbTableBook:setItems({'Todos os livros'});
    obj.cmbTableBook:setValues({'all'});
    obj.cmbTableBook:setValue("all");

    obj.layout16 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout16:setParent(obj.pnlTables);
    obj.layout16:setAlign("top");
    obj.layout16:setHeight(42);
    obj.layout16:setName("layout16");

    obj.label28 = GUI.fromHandle(_obj_newObject("label"));
    obj.label28:setParent(obj.layout16);
    obj.label28:setAlign("left");
    obj.label28:setWidth(55);
    obj.label28:setText("Tabela");
    obj.label28:setFontColor("#FFFFFF");
    obj.label28:setName("label28");

    obj.cmbGenericTable = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbGenericTable:setParent(obj.layout16);
    obj.cmbGenericTable:setName("cmbGenericTable");
    obj.cmbGenericTable:setAlign("left");
    obj.cmbGenericTable:setWidth(390);
    obj.cmbGenericTable:setItems({});
    obj.cmbGenericTable:setValues({});

    obj.button45 = GUI.fromHandle(_obj_newObject("button"));
    obj.button45:setParent(obj.layout16);
    obj.button45:setAlign("left");
    obj.button45:setWidth(90);
    obj.button45:setText("Rolar");
    obj.button45:setName("button45");

    obj.txtTableResult = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.txtTableResult:setParent(obj.pnlTables);
    obj.txtTableResult:setName("txtTableResult");
    obj.txtTableResult:setAlign("client");
    obj.txtTableResult:setReadOnly(true);
    obj.txtTableResult:setText("Reimporte os dados para carregar tables.json.");
    obj.txtTableResult:setFontColor("#EEEEEE");

    obj.pnlCraft = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlCraft:setParent(obj);
    obj.pnlCraft:setName("pnlCraft");
    obj.pnlCraft:setAlign("client");
    obj.pnlCraft:setVisible(false);
    obj.pnlCraft:setMargins({left=18, top=18, right=18, bottom=18});

    obj.label29 = GUI.fromHandle(_obj_newObject("label"));
    obj.label29:setParent(obj.pnlCraft);
    obj.label29:setAlign("top");
    obj.label29:setHeight(38);
    obj.label29:setText("Calculadora de crafting 2024");
    obj.label29:setFontSize(22);
    lfm_setPropAsString(obj.label29, "fontStyle", "bold");
    obj.label29:setFontColor("#FFFFFF");
    obj.label29:setName("label29");

    obj.lblCraftItem = GUI.fromHandle(_obj_newObject("label"));
    obj.lblCraftItem:setParent(obj.pnlCraft);
    obj.lblCraftItem:setName("lblCraftItem");
    obj.lblCraftItem:setAlign("top");
    obj.lblCraftItem:setHeight(30);
    obj.lblCraftItem:setText("Item magico");
    obj.lblCraftItem:setFontSize(17);
    obj.lblCraftItem:setFontColor("#C9A45C");

    obj.lblCraftRarity = GUI.fromHandle(_obj_newObject("label"));
    obj.lblCraftRarity:setParent(obj.pnlCraft);
    obj.lblCraftRarity:setName("lblCraftRarity");
    obj.lblCraftRarity:setAlign("top");
    obj.lblCraftRarity:setHeight(26);
    obj.lblCraftRarity:setText("Raridade");
    obj.lblCraftRarity:setFontColor("#CCCCCC");

    obj.layout17 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout17:setParent(obj.pnlCraft);
    obj.layout17:setAlign("top");
    obj.layout17:setHeight(40);
    obj.layout17:setName("layout17");

    obj.label30 = GUI.fromHandle(_obj_newObject("label"));
    obj.label30:setParent(obj.layout17);
    obj.label30:setAlign("left");
    obj.label30:setWidth(105);
    obj.label30:setText("Trabalhadores");
    obj.label30:setFontColor("#FFFFFF");
    obj.label30:setName("label30");

    obj.edtCraftWorkers = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtCraftWorkers:setParent(obj.layout17);
    obj.edtCraftWorkers:setName("edtCraftWorkers");
    obj.edtCraftWorkers:setAlign("left");
    obj.edtCraftWorkers:setWidth(60);
    obj.edtCraftWorkers:setText("1");

    obj.button46 = GUI.fromHandle(_obj_newObject("button"));
    obj.button46:setParent(obj.layout17);
    obj.button46:setAlign("left");
    obj.button46:setWidth(100);
    obj.button46:setText("Recalcular");
    obj.button46:setName("button46");

    obj.txtCraft = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.txtCraft:setParent(obj.pnlCraft);
    obj.txtCraft:setName("txtCraft");
    obj.txtCraft:setAlign("client");
    obj.txtCraft:setReadOnly(true);
    obj.txtCraft:setFontColor("#EEEEEE");

    obj.pnlLoot = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlLoot:setParent(obj);
    obj.pnlLoot:setName("pnlLoot");
    obj.pnlLoot:setAlign("client");
    obj.pnlLoot:setVisible(false);
    obj.pnlLoot:setMargins({left=18, top=18, right=18, bottom=18});

    obj.label31 = GUI.fromHandle(_obj_newObject("label"));
    obj.label31:setParent(obj.pnlLoot);
    obj.label31:setAlign("top");
    obj.label31:setHeight(42);
    obj.label31:setText("Gerador de loot individual por CR");
    obj.label31:setFontSize(22);
    lfm_setPropAsString(obj.label31, "fontStyle", "bold");
    obj.label31:setFontColor("#FFFFFF");
    obj.label31:setName("label31");

    obj.layout18 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout18:setParent(obj.pnlLoot);
    obj.layout18:setAlign("top");
    obj.layout18:setHeight(42);
    obj.layout18:setName("layout18");

    obj.label32 = GUI.fromHandle(_obj_newObject("label"));
    obj.label32:setParent(obj.layout18);
    obj.label32:setAlign("left");
    obj.label32:setWidth(42);
    obj.label32:setText("Tipo");
    obj.label32:setFontColor("#FFFFFF");
    obj.label32:setName("label32");

    obj.cmbLootMode = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbLootMode:setParent(obj.layout18);
    obj.cmbLootMode:setName("cmbLootMode");
    obj.cmbLootMode:setAlign("left");
    obj.cmbLootMode:setWidth(115);
    obj.cmbLootMode:setItems({'Individual','Hoard'});
    obj.cmbLootMode:setValues({'individual','hoard'});
    obj.cmbLootMode:setValue("individual");

    obj.label33 = GUI.fromHandle(_obj_newObject("label"));
    obj.label33:setParent(obj.layout18);
    obj.label33:setAlign("left");
    obj.label33:setWidth(35);
    obj.label33:setText("CR");
    obj.label33:setFontColor("#FFFFFF");
    obj.label33:setName("label33");

    obj.edtLootCR = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtLootCR:setParent(obj.layout18);
    obj.edtLootCR:setName("edtLootCR");
    obj.edtLootCR:setAlign("left");
    obj.edtLootCR:setWidth(70);
    obj.edtLootCR:setText("1");

    obj.label34 = GUI.fromHandle(_obj_newObject("label"));
    obj.label34:setParent(obj.layout18);
    obj.label34:setAlign("left");
    obj.label34:setWidth(55);
    obj.label34:setText("Edicao");
    obj.label34:setFontColor("#FFFFFF");
    obj.label34:setName("label34");

    obj.cmbLootEdition = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.cmbLootEdition:setParent(obj.layout18);
    obj.cmbLootEdition:setName("cmbLootEdition");
    obj.cmbLootEdition:setAlign("left");
    obj.cmbLootEdition:setWidth(95);
    obj.cmbLootEdition:setItems({'2014','2024'});
    obj.cmbLootEdition:setValues({'2014','2024'});
    obj.cmbLootEdition:setValue("2014");

    obj.button47 = GUI.fromHandle(_obj_newObject("button"));
    obj.button47:setParent(obj.layout18);
    obj.button47:setAlign("left");
    obj.button47:setWidth(90);
    obj.button47:setText("Gerar");
    obj.button47:setName("button47");

    obj.txtLoot = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.txtLoot:setParent(obj.pnlLoot);
    obj.txtLoot:setName("txtLoot");
    obj.txtLoot:setAlign("client");
    obj.txtLoot:setReadOnly(true);
    obj.txtLoot:setText("Importe data/loot.json para habilitar as tabelas.");
    obj.txtLoot:setFontColor("#EEEEEE");

    obj.pnlArea = GUI.fromHandle(_obj_newObject("layout"));
    obj.pnlArea:setParent(obj);
    obj.pnlArea:setName("pnlArea");
    obj.pnlArea:setAlign("client");
    obj.pnlArea:setVisible(false);
    obj.pnlArea:setMargins({left=18, top=18, right=18, bottom=18});

    obj.label35 = GUI.fromHandle(_obj_newObject("label"));
    obj.label35:setParent(obj.pnlArea);
    obj.label35:setAlign("top");
    obj.label35:setHeight(42);
    obj.label35:setText("Calculadora de area no grid");
    obj.label35:setFontSize(22);
    lfm_setPropAsString(obj.label35, "fontStyle", "bold");
    obj.label35:setFontColor("#FFFFFF");
    obj.label35:setName("label35");

    obj.label36 = GUI.fromHandle(_obj_newObject("label"));
    obj.label36:setParent(obj.pnlArea);
    obj.label36:setAlign("top");
    obj.label36:setHeight(34);
    obj.label36:setText("Convencao: 1 quadrado = 1,5 m; conta os quadrados cujo centro fica dentro do raio.");
    obj.label36:setFontColor("#CCCCCC");
    obj.label36:setName("label36");

    obj.layout19 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout19:setParent(obj.pnlArea);
    obj.layout19:setAlign("top");
    obj.layout19:setHeight(42);
    obj.layout19:setName("layout19");

    obj.label37 = GUI.fromHandle(_obj_newObject("label"));
    obj.label37:setParent(obj.layout19);
    obj.label37:setAlign("left");
    obj.label37:setWidth(120);
    obj.label37:setText("Raio (metros)");
    obj.label37:setFontColor("#FFFFFF");
    obj.label37:setName("label37");

    obj.edtAreaRadius = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtAreaRadius:setParent(obj.layout19);
    obj.edtAreaRadius:setName("edtAreaRadius");
    obj.edtAreaRadius:setAlign("left");
    obj.edtAreaRadius:setWidth(100);
    obj.edtAreaRadius:setText("4,5");

    obj.button48 = GUI.fromHandle(_obj_newObject("button"));
    obj.button48:setParent(obj.layout19);
    obj.button48:setAlign("left");
    obj.button48:setWidth(95);
    obj.button48:setText("Calcular");
    obj.button48:setName("button48");

    obj.lblAreaResult = GUI.fromHandle(_obj_newObject("label"));
    obj.lblAreaResult:setParent(obj.pnlArea);
    obj.lblAreaResult:setName("lblAreaResult");
    obj.lblAreaResult:setAlign("top");
    obj.lblAreaResult:setHeight(52);
    obj.lblAreaResult:setText("Exemplo: informe 4,5 e clique Calcular.");
    obj.lblAreaResult:setFontColor("#C9A45C");
    obj.lblAreaResult:setFontSize(16);

    obj.label38 = GUI.fromHandle(_obj_newObject("label"));
    obj.label38:setParent(obj.pnlArea);
    obj.label38:setAlign("top");
    obj.label38:setHeight(70);
    obj.label38:setText("O resultado e uma ajuda de mesa, nao substitui a forma/posicionamento descritos pela regra ou magia. Para cones, linhas e cubos, use a geometria especifica do efeito.");
    obj.label38:setFontColor("#AAAAAA");
    obj.label38:setName("label38");

    obj._e_event0 = obj:addEventListener("onShow",
        function ()
            resetView();  self.pnlSpellFilters.visible=false; self.pnlCreatureFilters.visible=false; self.pnlItemFilters.visible=false; self.pnlRarityChecks.visible=false; self.lblCount.text="Escolha uma secao";
        end);

    obj._e_event1 = obj.button1:addEventListener("onClick",
        function (event)
            chooseSection("all","Busca Global")
        end);

    obj._e_event2 = obj.button2:addEventListener("onClick",
        function (event)
            chooseSection("spell","Magias")
        end);

    obj._e_event3 = obj.button3:addEventListener("onClick",
        function (event)
            chooseSection("species","Especies")
        end);

    obj._e_event4 = obj.button4:addEventListener("onClick",
        function (event)
            chooseSection("class","Classes")
        end);

    obj._e_event5 = obj.button5:addEventListener("onClick",
        function (event)
            chooseSection("feat","Feats")
        end);

    obj._e_event6 = obj.button6:addEventListener("onClick",
        function (event)
            chooseSection("item","Itens")
        end);

    obj._e_event7 = obj.button7:addEventListener("onClick",
        function (event)
            chooseSection("magicitem","Itens Magicos")
        end);

    obj._e_event8 = obj.button8:addEventListener("onClick",
        function (event)
            chooseSection("creature","Criaturas")
        end);

    obj._e_event9 = obj.button9:addEventListener("onClick",
        function (event)
            chooseSection("condition","Regras")
        end);

    obj._e_event10 = obj.button10:addEventListener("onClick",
        function (event)
            toggleReferenceNav()
        end);

    obj._e_event11 = obj.button11:addEventListener("onClick",
        function (event)
            showFavorites()
        end);

    obj._e_event12 = obj.button12:addEventListener("onClick",
        function (event)
            showAreaTool()
        end);

    obj._e_event13 = obj.button13:addEventListener("onClick",
        function (event)
            showLoot()
        end);

    obj._e_event14 = obj.button14:addEventListener("onClick",
        function (event)
            showCraftingTab()
        end);

    obj._e_event15 = obj.button15:addEventListener("onClick",
        function (event)
            showTables()
        end);

    obj._e_event16 = obj.button16:addEventListener("onClick",
        function (event)
            showEncounters()
        end);

    obj._e_event17 = obj.button17:addEventListener("onClick",
        function (event)
            showStats()
        end);

    obj._e_event18 = obj.button18:addEventListener("onClick",
        function (event)
            showCR()
        end);

    obj._e_event19 = obj.button19:addEventListener("onClick",
        function (event)
            showQuickReference()
        end);

    obj._e_event20 = obj.button20:addEventListener("onClick",
        function (event)
            searchNow()
        end);

    obj._e_event21 = obj.button21:addEventListener("onClick",
        function (event)
            clearSearch()
        end);

    obj._e_event22 = obj.button22:addEventListener("onClick",
        function (event)
            chooseSection("optionalfeature","Opcoes e Features")
        end);

    obj._e_event23 = obj.button23:addEventListener("onClick",
        function (event)
            chooseSection("background","Backgrounds")
        end);

    obj._e_event24 = obj.button24:addEventListener("onClick",
        function (event)
            chooseSection("charoption","Opcoes de Personagem")
        end);

    obj._e_event25 = obj.button25:addEventListener("onClick",
        function (event)
            chooseSection("actionref","Acoes")
        end);

    obj._e_event26 = obj.button26:addEventListener("onClick",
        function (event)
            chooseSection("reward","Recompensas")
        end);

    obj._e_event27 = obj.button27:addEventListener("onClick",
        function (event)
            chooseSection("object","Objetos")
        end);

    obj._e_event28 = obj.button28:addEventListener("onClick",
        function (event)
            chooseSection("traphazard","Armadilhas e Perigos")
        end);

    obj._e_event29 = obj.button29:addEventListener("onClick",
        function (event)
            chooseSection("psionic","Psionicos")
        end);

    obj._e_event30 = obj.button30:addEventListener("onClick",
        function (event)
            chooseSection("vehicle","Veiculos")
        end);

    obj._e_event31 = obj.cmbSource:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event32 = obj.cmbEdition:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event33 = obj.cmbOrigin:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event34 = obj.cmbLevel:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event35 = obj.cmbSchool:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event36 = obj.cmbSpellClass:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event37 = obj.chkRitual:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event38 = obj.chkConc:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event39 = obj.cmbCR:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event40 = obj.cmbCreatureType:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event41 = obj.cmbSize:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event42 = obj.chkWeapon:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event43 = obj.chkArmor:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event44 = obj.chkGear:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event45 = obj.chkOtherType:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event46 = obj.cmbAttune:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event47 = obj.chkCommon:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event48 = obj.chkUncommon:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event49 = obj.chkRare:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event50 = obj.chkVeryRare:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event51 = obj.chkLegendary:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event52 = obj.chkArtifact:addEventListener("onChange",
        function ()
            searchNow()
        end);

    obj._e_event53 = obj.row1:addEventListener("onClick",
        function (event)
            openSlot(1)
        end);

    obj._e_event54 = obj.row2:addEventListener("onClick",
        function (event)
            openSlot(2)
        end);

    obj._e_event55 = obj.row3:addEventListener("onClick",
        function (event)
            openSlot(3)
        end);

    obj._e_event56 = obj.row4:addEventListener("onClick",
        function (event)
            openSlot(4)
        end);

    obj._e_event57 = obj.row5:addEventListener("onClick",
        function (event)
            openSlot(5)
        end);

    obj._e_event58 = obj.row6:addEventListener("onClick",
        function (event)
            openSlot(6)
        end);

    obj._e_event59 = obj.row7:addEventListener("onClick",
        function (event)
            openSlot(7)
        end);

    obj._e_event60 = obj.row8:addEventListener("onClick",
        function (event)
            openSlot(8)
        end);

    obj._e_event61 = obj.row9:addEventListener("onClick",
        function (event)
            openSlot(9)
        end);

    obj._e_event62 = obj.row10:addEventListener("onClick",
        function (event)
            openSlot(10)
        end);

    obj._e_event63 = obj.row11:addEventListener("onClick",
        function (event)
            openSlot(11)
        end);

    obj._e_event64 = obj.row12:addEventListener("onClick",
        function (event)
            openSlot(12)
        end);

    obj._e_event65 = obj.row13:addEventListener("onClick",
        function (event)
            openSlot(13)
        end);

    obj._e_event66 = obj.row14:addEventListener("onClick",
        function (event)
            openSlot(14)
        end);

    obj._e_event67 = obj.row15:addEventListener("onClick",
        function (event)
            openSlot(15)
        end);

    obj._e_event68 = obj.button31:addEventListener("onClick",
        function (event)
            creatureSection("all")
        end);

    obj._e_event69 = obj.button32:addEventListener("onClick",
        function (event)
            creatureSection("stats")
        end);

    obj._e_event70 = obj.button33:addEventListener("onClick",
        function (event)
            creatureSection("traits")
        end);

    obj._e_event71 = obj.button34:addEventListener("onClick",
        function (event)
            creatureSection("actions")
        end);

    obj._e_event72 = obj.button35:addEventListener("onClick",
        function (event)
            creatureSection("bonus")
        end);

    obj._e_event73 = obj.button36:addEventListener("onClick",
        function (event)
            creatureSection("reactions")
        end);

    obj._e_event74 = obj.button37:addEventListener("onClick",
        function (event)
            creatureSection("legendary")
        end);

    obj._e_event75 = obj.btnFavorite:addEventListener("onClick",
        function (event)
            toggleFavorite()
        end);

    obj._e_event76 = obj.btnCraft:addEventListener("onClick",
        function (event)
            openCrafting()
        end);

    obj._e_event77 = obj.button38:addEventListener("onClick",
        function (event)
            prevPage()
        end);

    obj._e_event78 = obj.button39:addEventListener("onClick",
        function (event)
            nextPage()
        end);

    obj._e_event79 = obj.button40:addEventListener("onClick",
        function (event)
            calculateCR()
        end);

    obj._e_event80 = obj.button41:addEventListener("onClick",
        function (event)
            self.txtStats.text="15, 14, 13, 12, 10, 8"
        end);

    obj._e_event81 = obj.button42:addEventListener("onClick",
        function (event)
            pointBuy()
        end);

    obj._e_event82 = obj.button43:addEventListener("onClick",
        function (event)
            rollStats()
        end);

    obj._e_event83 = obj.button44:addEventListener("onClick",
        function (event)
            rollEncounter()
        end);

    obj._e_event84 = obj.edtTableSearch:addEventListener("onChange",
        function ()
            filterGenericTables()
        end);

    obj._e_event85 = obj.cmbTableBook:addEventListener("onChange",
        function ()
            filterGenericTables()
        end);

    obj._e_event86 = obj.button45:addEventListener("onClick",
        function (event)
            rollGenericTable()
        end);

    obj._e_event87 = obj.button46:addEventListener("onClick",
        function (event)
            calculateCrafting()
        end);

    obj._e_event88 = obj.button47:addEventListener("onClick",
        function (event)
            generateLoot()
        end);

    obj._e_event89 = obj.button48:addEventListener("onClick",
        function (event)
            areaCalculate()
        end);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event89);
        __o_rrpgObjs.removeEventListenerById(self._e_event88);
        __o_rrpgObjs.removeEventListenerById(self._e_event87);
        __o_rrpgObjs.removeEventListenerById(self._e_event86);
        __o_rrpgObjs.removeEventListenerById(self._e_event85);
        __o_rrpgObjs.removeEventListenerById(self._e_event84);
        __o_rrpgObjs.removeEventListenerById(self._e_event83);
        __o_rrpgObjs.removeEventListenerById(self._e_event82);
        __o_rrpgObjs.removeEventListenerById(self._e_event81);
        __o_rrpgObjs.removeEventListenerById(self._e_event80);
        __o_rrpgObjs.removeEventListenerById(self._e_event79);
        __o_rrpgObjs.removeEventListenerById(self._e_event78);
        __o_rrpgObjs.removeEventListenerById(self._e_event77);
        __o_rrpgObjs.removeEventListenerById(self._e_event76);
        __o_rrpgObjs.removeEventListenerById(self._e_event75);
        __o_rrpgObjs.removeEventListenerById(self._e_event74);
        __o_rrpgObjs.removeEventListenerById(self._e_event73);
        __o_rrpgObjs.removeEventListenerById(self._e_event72);
        __o_rrpgObjs.removeEventListenerById(self._e_event71);
        __o_rrpgObjs.removeEventListenerById(self._e_event70);
        __o_rrpgObjs.removeEventListenerById(self._e_event69);
        __o_rrpgObjs.removeEventListenerById(self._e_event68);
        __o_rrpgObjs.removeEventListenerById(self._e_event67);
        __o_rrpgObjs.removeEventListenerById(self._e_event66);
        __o_rrpgObjs.removeEventListenerById(self._e_event65);
        __o_rrpgObjs.removeEventListenerById(self._e_event64);
        __o_rrpgObjs.removeEventListenerById(self._e_event63);
        __o_rrpgObjs.removeEventListenerById(self._e_event62);
        __o_rrpgObjs.removeEventListenerById(self._e_event61);
        __o_rrpgObjs.removeEventListenerById(self._e_event60);
        __o_rrpgObjs.removeEventListenerById(self._e_event59);
        __o_rrpgObjs.removeEventListenerById(self._e_event58);
        __o_rrpgObjs.removeEventListenerById(self._e_event57);
        __o_rrpgObjs.removeEventListenerById(self._e_event56);
        __o_rrpgObjs.removeEventListenerById(self._e_event55);
        __o_rrpgObjs.removeEventListenerById(self._e_event54);
        __o_rrpgObjs.removeEventListenerById(self._e_event53);
        __o_rrpgObjs.removeEventListenerById(self._e_event52);
        __o_rrpgObjs.removeEventListenerById(self._e_event51);
        __o_rrpgObjs.removeEventListenerById(self._e_event50);
        __o_rrpgObjs.removeEventListenerById(self._e_event49);
        __o_rrpgObjs.removeEventListenerById(self._e_event48);
        __o_rrpgObjs.removeEventListenerById(self._e_event47);
        __o_rrpgObjs.removeEventListenerById(self._e_event46);
        __o_rrpgObjs.removeEventListenerById(self._e_event45);
        __o_rrpgObjs.removeEventListenerById(self._e_event44);
        __o_rrpgObjs.removeEventListenerById(self._e_event43);
        __o_rrpgObjs.removeEventListenerById(self._e_event42);
        __o_rrpgObjs.removeEventListenerById(self._e_event41);
        __o_rrpgObjs.removeEventListenerById(self._e_event40);
        __o_rrpgObjs.removeEventListenerById(self._e_event39);
        __o_rrpgObjs.removeEventListenerById(self._e_event38);
        __o_rrpgObjs.removeEventListenerById(self._e_event37);
        __o_rrpgObjs.removeEventListenerById(self._e_event36);
        __o_rrpgObjs.removeEventListenerById(self._e_event35);
        __o_rrpgObjs.removeEventListenerById(self._e_event34);
        __o_rrpgObjs.removeEventListenerById(self._e_event33);
        __o_rrpgObjs.removeEventListenerById(self._e_event32);
        __o_rrpgObjs.removeEventListenerById(self._e_event31);
        __o_rrpgObjs.removeEventListenerById(self._e_event30);
        __o_rrpgObjs.removeEventListenerById(self._e_event29);
        __o_rrpgObjs.removeEventListenerById(self._e_event28);
        __o_rrpgObjs.removeEventListenerById(self._e_event27);
        __o_rrpgObjs.removeEventListenerById(self._e_event26);
        __o_rrpgObjs.removeEventListenerById(self._e_event25);
        __o_rrpgObjs.removeEventListenerById(self._e_event24);
        __o_rrpgObjs.removeEventListenerById(self._e_event23);
        __o_rrpgObjs.removeEventListenerById(self._e_event22);
        __o_rrpgObjs.removeEventListenerById(self._e_event21);
        __o_rrpgObjs.removeEventListenerById(self._e_event20);
        __o_rrpgObjs.removeEventListenerById(self._e_event19);
        __o_rrpgObjs.removeEventListenerById(self._e_event18);
        __o_rrpgObjs.removeEventListenerById(self._e_event17);
        __o_rrpgObjs.removeEventListenerById(self._e_event16);
        __o_rrpgObjs.removeEventListenerById(self._e_event15);
        __o_rrpgObjs.removeEventListenerById(self._e_event14);
        __o_rrpgObjs.removeEventListenerById(self._e_event13);
        __o_rrpgObjs.removeEventListenerById(self._e_event12);
        __o_rrpgObjs.removeEventListenerById(self._e_event11);
        __o_rrpgObjs.removeEventListenerById(self._e_event10);
        __o_rrpgObjs.removeEventListenerById(self._e_event9);
        __o_rrpgObjs.removeEventListenerById(self._e_event8);
        __o_rrpgObjs.removeEventListenerById(self._e_event7);
        __o_rrpgObjs.removeEventListenerById(self._e_event6);
        __o_rrpgObjs.removeEventListenerById(self._e_event5);
        __o_rrpgObjs.removeEventListenerById(self._e_event4);
        __o_rrpgObjs.removeEventListenerById(self._e_event3);
        __o_rrpgObjs.removeEventListenerById(self._e_event2);
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.layout8 ~= nil then self.layout8:destroy(); self.layout8 = nil; end;
        if self.chkLegendary ~= nil then self.chkLegendary:destroy(); self.chkLegendary = nil; end;
        if self.layout11 ~= nil then self.layout11:destroy(); self.layout11 = nil; end;
        if self.label37 ~= nil then self.label37:destroy(); self.label37 = nil; end;
        if self.edtCRHP ~= nil then self.edtCRHP:destroy(); self.edtCRHP = nil; end;
        if self.layout3 ~= nil then self.layout3:destroy(); self.layout3 = nil; end;
        if self.button11 ~= nil then self.button11:destroy(); self.button11 = nil; end;
        if self.button25 ~= nil then self.button25:destroy(); self.button25 = nil; end;
        if self.lblCount ~= nil then self.lblCount:destroy(); self.lblCount = nil; end;
        if self.row7 ~= nil then self.row7:destroy(); self.row7 = nil; end;
        if self.cmbEncounterTable ~= nil then self.cmbEncounterTable:destroy(); self.cmbEncounterTable = nil; end;
        if self.button28 ~= nil then self.button28:destroy(); self.button28 = nil; end;
        if self.chkOtherType ~= nil then self.chkOtherType:destroy(); self.chkOtherType = nil; end;
        if self.row2 ~= nil then self.row2:destroy(); self.row2 = nil; end;
        if self.lblCraftRarity ~= nil then self.lblCraftRarity:destroy(); self.lblCraftRarity = nil; end;
        if self.label10 ~= nil then self.label10:destroy(); self.label10 = nil; end;
        if self.label22 ~= nil then self.label22:destroy(); self.label22 = nil; end;
        if self.cmbTableBook ~= nil then self.cmbTableBook:destroy(); self.cmbTableBook = nil; end;
        if self.pnlCraft ~= nil then self.pnlCraft:destroy(); self.pnlCraft = nil; end;
        if self.label15 ~= nil then self.label15:destroy(); self.label15 = nil; end;
        if self.label29 ~= nil then self.label29:destroy(); self.label29 = nil; end;
        if self.edtCRAC ~= nil then self.edtCRAC:destroy(); self.edtCRAC = nil; end;
        if self.lblPage ~= nil then self.lblPage:destroy(); self.lblPage = nil; end;
        if self.button44 ~= nil then self.button44:destroy(); self.button44 = nil; end;
        if self.pnlCreatureTabs ~= nil then self.pnlCreatureTabs:destroy(); self.pnlCreatureTabs = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        if self.txtLoot ~= nil then self.txtLoot:destroy(); self.txtLoot = nil; end;
        if self.chkWeapon ~= nil then self.chkWeapon:destroy(); self.chkWeapon = nil; end;
        if self.cmbCreatureType ~= nil then self.cmbCreatureType:destroy(); self.cmbCreatureType = nil; end;
        if self.button8 ~= nil then self.button8:destroy(); self.button8 = nil; end;
        if self.row14 ~= nil then self.row14:destroy(); self.row14 = nil; end;
        if self.cmbSchool ~= nil then self.cmbSchool:destroy(); self.cmbSchool = nil; end;
        if self.button34 ~= nil then self.button34:destroy(); self.button34 = nil; end;
        if self.txtDetails ~= nil then self.txtDetails:destroy(); self.txtDetails = nil; end;
        if self.pnlEncounters ~= nil then self.pnlEncounters:destroy(); self.pnlEncounters = nil; end;
        if self.txtTableResult ~= nil then self.txtTableResult:destroy(); self.txtTableResult = nil; end;
        if self.edtSearch ~= nil then self.edtSearch:destroy(); self.edtSearch = nil; end;
        if self.row11 ~= nil then self.row11:destroy(); self.row11 = nil; end;
        if self.button3 ~= nil then self.button3:destroy(); self.button3 = nil; end;
        if self.layout18 ~= nil then self.layout18:destroy(); self.layout18 = nil; end;
        if self.edtLootCR ~= nil then self.edtLootCR:destroy(); self.edtLootCR = nil; end;
        if self.button18 ~= nil then self.button18:destroy(); self.button18 = nil; end;
        if self.label9 ~= nil then self.label9:destroy(); self.label9 = nil; end;
        if self.layout15 ~= nil then self.layout15:destroy(); self.layout15 = nil; end;
        if self.button6 ~= nil then self.button6:destroy(); self.button6 = nil; end;
        if self.label33 ~= nil then self.label33:destroy(); self.label33 = nil; end;
        if self.layout7 ~= nil then self.layout7:destroy(); self.layout7 = nil; end;
        if self.pnlBrowser ~= nil then self.pnlBrowser:destroy(); self.pnlBrowser = nil; end;
        if self.button21 ~= nil then self.button21:destroy(); self.button21 = nil; end;
        if self.btnFavorite ~= nil then self.btnFavorite:destroy(); self.btnFavorite = nil; end;
        if self.layout2 ~= nil then self.layout2:destroy(); self.layout2 = nil; end;
        if self.edtStatDrop ~= nil then self.edtStatDrop:destroy(); self.edtStatDrop = nil; end;
        if self.label7 ~= nil then self.label7:destroy(); self.label7 = nil; end;
        if self.button16 ~= nil then self.button16:destroy(); self.button16 = nil; end;
        if self.button24 ~= nil then self.button24:destroy(); self.button24 = nil; end;
        if self.row6 ~= nil then self.row6:destroy(); self.row6 = nil; end;
        if self.cmbEdition ~= nil then self.cmbEdition:destroy(); self.cmbEdition = nil; end;
        if self.row1 ~= nil then self.row1:destroy(); self.row1 = nil; end;
        if self.edtAreaRadius ~= nil then self.edtAreaRadius:destroy(); self.edtAreaRadius = nil; end;
        if self.label11 ~= nil then self.label11:destroy(); self.label11 = nil; end;
        if self.label25 ~= nil then self.label25:destroy(); self.label25 = nil; end;
        if self.pnlReferenceNav ~= nil then self.pnlReferenceNav:destroy(); self.pnlReferenceNav = nil; end;
        if self.lblTitle ~= nil then self.lblTitle:destroy(); self.lblTitle = nil; end;
        if self.lblAttune ~= nil then self.lblAttune:destroy(); self.lblAttune = nil; end;
        if self.label28 ~= nil then self.label28:destroy(); self.label28 = nil; end;
        if self.button43 ~= nil then self.button43:destroy(); self.button43 = nil; end;
        if self.button30 ~= nil then self.button30:destroy(); self.button30 = nil; end;
        if self.cmbItemType ~= nil then self.cmbItemType:destroy(); self.cmbItemType = nil; end;
        if self.rectangle2 ~= nil then self.rectangle2:destroy(); self.rectangle2 = nil; end;
        if self.row15 ~= nil then self.row15:destroy(); self.row15 = nil; end;
        if self.chkGear ~= nil then self.chkGear:destroy(); self.chkGear = nil; end;
        if self.button35 ~= nil then self.button35:destroy(); self.button35 = nil; end;
        if self.cmbLevel ~= nil then self.cmbLevel:destroy(); self.cmbLevel = nil; end;
        if self.edtCRDC ~= nil then self.edtCRDC:destroy(); self.edtCRDC = nil; end;
        if self.layout19 ~= nil then self.layout19:destroy(); self.layout19 = nil; end;
        if self.button2 ~= nil then self.button2:destroy(); self.button2 = nil; end;
        if self.button19 ~= nil then self.button19:destroy(); self.button19 = nil; end;
        if self.label8 ~= nil then self.label8:destroy(); self.label8 = nil; end;
        if self.layout12 ~= nil then self.layout12:destroy(); self.layout12 = nil; end;
        if self.button5 ~= nil then self.button5:destroy(); self.button5 = nil; end;
        if self.pnlLoot ~= nil then self.pnlLoot:destroy(); self.pnlLoot = nil; end;
        if self.edtTableSearch ~= nil then self.edtTableSearch:destroy(); self.edtTableSearch = nil; end;
        if self.layout6 ~= nil then self.layout6:destroy(); self.layout6 = nil; end;
        if self.pnlItemFilters ~= nil then self.pnlItemFilters:destroy(); self.pnlItemFilters = nil; end;
        if self.label34 ~= nil then self.label34:destroy(); self.label34 = nil; end;
        if self.button12 ~= nil then self.button12:destroy(); self.button12 = nil; end;
        if self.button20 ~= nil then self.button20:destroy(); self.button20 = nil; end;
        if self.label3 ~= nil then self.label3:destroy(); self.label3 = nil; end;
        if self.cmbSpellClass ~= nil then self.cmbSpellClass:destroy(); self.cmbSpellClass = nil; end;
        if self.cmbCR ~= nil then self.cmbCR:destroy(); self.cmbCR = nil; end;
        if self.layout1 ~= nil then self.layout1:destroy(); self.layout1 = nil; end;
        if self.label18 ~= nil then self.label18:destroy(); self.label18 = nil; end;
        if self.button17 ~= nil then self.button17:destroy(); self.button17 = nil; end;
        if self.button27 ~= nil then self.button27:destroy(); self.button27 = nil; end;
        if self.label6 ~= nil then self.label6:destroy(); self.label6 = nil; end;
        if self.row5 ~= nil then self.row5:destroy(); self.row5 = nil; end;
        if self.txtCraft ~= nil then self.txtCraft:destroy(); self.txtCraft = nil; end;
        if self.label21 ~= nil then self.label21:destroy(); self.label21 = nil; end;
        if self.lblSection ~= nil then self.lblSection:destroy(); self.lblSection = nil; end;
        if self.label16 ~= nil then self.label16:destroy(); self.label16 = nil; end;
        if self.label24 ~= nil then self.label24:destroy(); self.label24 = nil; end;
        if self.pnlStats ~= nil then self.pnlStats:destroy(); self.pnlStats = nil; end;
        if self.button47 ~= nil then self.button47:destroy(); self.button47 = nil; end;
        if self.edtStatDice ~= nil then self.edtStatDice:destroy(); self.edtStatDice = nil; end;
        if self.button42 ~= nil then self.button42:destroy(); self.button42 = nil; end;
        if self.edtCRDPR ~= nil then self.edtCRDPR:destroy(); self.edtCRDPR = nil; end;
        if self.button31 ~= nil then self.button31:destroy(); self.button31 = nil; end;
        if self.txtStats ~= nil then self.txtStats:destroy(); self.txtStats = nil; end;
        if self.chkRare ~= nil then self.chkRare:destroy(); self.chkRare = nil; end;
        if self.chkUncommon ~= nil then self.chkUncommon:destroy(); self.chkUncommon = nil; end;
        if self.cmbSize ~= nil then self.cmbSize:destroy(); self.cmbSize = nil; end;
        if self.row12 ~= nil then self.row12:destroy(); self.row12 = nil; end;
        if self.button36 ~= nil then self.button36:destroy(); self.button36 = nil; end;
        if self.button48 ~= nil then self.button48:destroy(); self.button48 = nil; end;
        if self.layout16 ~= nil then self.layout16:destroy(); self.layout16 = nil; end;
        if self.label30 ~= nil then self.label30:destroy(); self.label30 = nil; end;
        if self.button1 ~= nil then self.button1:destroy(); self.button1 = nil; end;
        if self.chkCommon ~= nil then self.chkCommon:destroy(); self.chkCommon = nil; end;
        if self.lblRarity ~= nil then self.lblRarity:destroy(); self.lblRarity = nil; end;
        if self.cmbSource ~= nil then self.cmbSource:destroy(); self.cmbSource = nil; end;
        if self.layout13 ~= nil then self.layout13:destroy(); self.layout13 = nil; end;
        if self.label35 ~= nil then self.label35:destroy(); self.label35 = nil; end;
        if self.button4 ~= nil then self.button4:destroy(); self.button4 = nil; end;
        if self.layout5 ~= nil then self.layout5:destroy(); self.layout5 = nil; end;
        if self.pnlCR ~= nil then self.pnlCR:destroy(); self.pnlCR = nil; end;
        if self.button13 ~= nil then self.button13:destroy(); self.button13 = nil; end;
        if self.label2 ~= nil then self.label2:destroy(); self.label2 = nil; end;
        if self.button23 ~= nil then self.button23:destroy(); self.button23 = nil; end;
        if self.chkArtifact ~= nil then self.chkArtifact:destroy(); self.chkArtifact = nil; end;
        if self.pnlTables ~= nil then self.pnlTables:destroy(); self.pnlTables = nil; end;
        if self.row9 ~= nil then self.row9:destroy(); self.row9 = nil; end;
        if self.lblAreaResult ~= nil then self.lblAreaResult:destroy(); self.lblAreaResult = nil; end;
        if self.label19 ~= nil then self.label19:destroy(); self.label19 = nil; end;
        if self.button14 ~= nil then self.button14:destroy(); self.button14 = nil; end;
        if self.button26 ~= nil then self.button26:destroy(); self.button26 = nil; end;
        if self.label5 ~= nil then self.label5:destroy(); self.label5 = nil; end;
        if self.row4 ~= nil then self.row4:destroy(); self.row4 = nil; end;
        if self.label12 ~= nil then self.label12:destroy(); self.label12 = nil; end;
        if self.label20 ~= nil then self.label20:destroy(); self.label20 = nil; end;
        if self.lblCraftItem ~= nil then self.lblCraftItem:destroy(); self.lblCraftItem = nil; end;
        if self.button38 ~= nil then self.button38:destroy(); self.button38 = nil; end;
        if self.label17 ~= nil then self.label17:destroy(); self.label17 = nil; end;
        if self.cmbAttune ~= nil then self.cmbAttune:destroy(); self.cmbAttune = nil; end;
        if self.label27 ~= nil then self.label27:destroy(); self.label27 = nil; end;
        if self.button46 ~= nil then self.button46:destroy(); self.button46 = nil; end;
        if self.txtEncounter ~= nil then self.txtEncounter:destroy(); self.txtEncounter = nil; end;
        if self.button41 ~= nil then self.button41:destroy(); self.button41 = nil; end;
        if self.button32 ~= nil then self.button32:destroy(); self.button32 = nil; end;
        if self.chkVeryRare ~= nil then self.chkVeryRare:destroy(); self.chkVeryRare = nil; end;
        if self.txtCR ~= nil then self.txtCR:destroy(); self.txtCR = nil; end;
        if self.row13 ~= nil then self.row13:destroy(); self.row13 = nil; end;
        if self.button37 ~= nil then self.button37:destroy(); self.button37 = nil; end;
        if self.layout17 ~= nil then self.layout17:destroy(); self.layout17 = nil; end;
        if self.label31 ~= nil then self.label31:destroy(); self.label31 = nil; end;
        if self.chkArmor ~= nil then self.chkArmor:destroy(); self.chkArmor = nil; end;
        if self.layout9 ~= nil then self.layout9:destroy(); self.layout9 = nil; end;
        if self.edtCRAttack ~= nil then self.edtCRAttack:destroy(); self.edtCRAttack = nil; end;
        if self.chkRitual ~= nil then self.chkRitual:destroy(); self.chkRitual = nil; end;
        if self.layout10 ~= nil then self.layout10:destroy(); self.layout10 = nil; end;
        if self.btnCraft ~= nil then self.btnCraft:destroy(); self.btnCraft = nil; end;
        if self.label36 ~= nil then self.label36:destroy(); self.label36 = nil; end;
        if self.layout4 ~= nil then self.layout4:destroy(); self.layout4 = nil; end;
        if self.cmbOrigin ~= nil then self.cmbOrigin:destroy(); self.cmbOrigin = nil; end;
        if self.button10 ~= nil then self.button10:destroy(); self.button10 = nil; end;
        if self.label1 ~= nil then self.label1:destroy(); self.label1 = nil; end;
        if self.button22 ~= nil then self.button22:destroy(); self.button22 = nil; end;
        if self.chkConc ~= nil then self.chkConc:destroy(); self.chkConc = nil; end;
        if self.cmbLootMode ~= nil then self.cmbLootMode:destroy(); self.cmbLootMode = nil; end;
        if self.row8 ~= nil then self.row8:destroy(); self.row8 = nil; end;
        if self.button15 ~= nil then self.button15:destroy(); self.button15 = nil; end;
        if self.button29 ~= nil then self.button29:destroy(); self.button29 = nil; end;
        if self.label4 ~= nil then self.label4:destroy(); self.label4 = nil; end;
        if self.row3 ~= nil then self.row3:destroy(); self.row3 = nil; end;
        if self.label13 ~= nil then self.label13:destroy(); self.label13 = nil; end;
        if self.label23 ~= nil then self.label23:destroy(); self.label23 = nil; end;
        if self.pnlCreatureFilters ~= nil then self.pnlCreatureFilters:destroy(); self.pnlCreatureFilters = nil; end;
        if self.button39 ~= nil then self.button39:destroy(); self.button39 = nil; end;
        if self.pnlSpellFilters ~= nil then self.pnlSpellFilters:destroy(); self.pnlSpellFilters = nil; end;
        if self.label14 ~= nil then self.label14:destroy(); self.label14 = nil; end;
        if self.label26 ~= nil then self.label26:destroy(); self.label26 = nil; end;
        if self.edtCraftWorkers ~= nil then self.edtCraftWorkers:destroy(); self.edtCraftWorkers = nil; end;
        if self.pnlCommonFilters ~= nil then self.pnlCommonFilters:destroy(); self.pnlCommonFilters = nil; end;
        if self.button45 ~= nil then self.button45:destroy(); self.button45 = nil; end;
        if self.cmbRarity ~= nil then self.cmbRarity:destroy(); self.cmbRarity = nil; end;
        if self.cmbGenericTable ~= nil then self.cmbGenericTable:destroy(); self.cmbGenericTable = nil; end;
        if self.lblSub ~= nil then self.lblSub:destroy(); self.lblSub = nil; end;
        if self.chkCRSave ~= nil then self.chkCRSave:destroy(); self.chkCRSave = nil; end;
        if self.button40 ~= nil then self.button40:destroy(); self.button40 = nil; end;
        if self.pnlArea ~= nil then self.pnlArea:destroy(); self.pnlArea = nil; end;
        if self.label38 ~= nil then self.label38:destroy(); self.label38 = nil; end;
        if self.button9 ~= nil then self.button9:destroy(); self.button9 = nil; end;
        if self.button33 ~= nil then self.button33:destroy(); self.button33 = nil; end;
        if self.pnlRarityChecks ~= nil then self.pnlRarityChecks:destroy(); self.pnlRarityChecks = nil; end;
        if self.row10 ~= nil then self.row10:destroy(); self.row10 = nil; end;
        if self.layout14 ~= nil then self.layout14:destroy(); self.layout14 = nil; end;
        if self.label32 ~= nil then self.label32:destroy(); self.label32 = nil; end;
        if self.button7 ~= nil then self.button7:destroy(); self.button7 = nil; end;
        if self.cmbLootEdition ~= nil then self.cmbLootEdition:destroy(); self.cmbLootEdition = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newfrmCompendium5e()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_frmCompendium5e();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _frmCompendium5e = {
    newEditor = newfrmCompendium5e, 
    new = newfrmCompendium5e, 
    name = "frmCompendium5e", 
    dataType = "br.com.minebr55.compendium5e", 
    formType = "tablesDock", 
    formComponentName = "form", 
    cacheMode = "none", 
    title = "Compendio 5e", 
    description=""};

frmCompendium5e = _frmCompendium5e;
Firecast.registrarForm(_frmCompendium5e);
Firecast.registrarDataType(_frmCompendium5e);
Firecast.registrarSpecialForm(_frmCompendium5e);

return _frmCompendium5e;
