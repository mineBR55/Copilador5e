@echo off
rdk c
pause
