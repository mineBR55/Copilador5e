@echo off
setlocal
set "LOCAL_ARG="
if not "%~1"=="" set "LOCAL_ARG=--local "%~1""
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\update_data.py %LOCAL_ARG%
) else (
  python tools\update_data.py %LOCAL_ARG%
)
if errorlevel 1 (
  echo.
  echo Falha ao atualizar os dados.
  echo Se o erro for getaddrinfo failed, teste sua conexao/DNS ou use:
  echo atualizar_dados.bat "C:\caminho\para\5etools\data"
  pause
  exit /b 1
)
echo.
echo Atualizacao concluida.
pause
