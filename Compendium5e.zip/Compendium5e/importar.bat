@echo off
set "SOURCE=%~1"
if "%SOURCE%"=="" (
  echo Arraste a pasta data do 5etools sobre este arquivo ou execute:
  echo importar.bat "C:\caminho\para\5etools\data"
  pause
  exit /b 1
)
py -3 tools\import_5etools.py --source "%SOURCE%" --output data
pause
